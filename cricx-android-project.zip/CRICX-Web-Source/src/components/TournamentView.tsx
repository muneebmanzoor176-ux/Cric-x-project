import React, { useState } from 'react';
import { Plus, Play, Trash2, Trophy, X } from 'lucide-react';
import {
  Match,
  MatchTeamSnapshot,
  Team,
  Tournament,
  TournamentFixture,
} from '../types/cricket';
import {
  computeTournamentStandings,
  createId,
} from '../engine/cricketEngine';

interface TournamentViewProps {
  tournaments: Tournament[];
  teams: Team[];
  matches: Match[];
  onSaveTournaments: (list: Tournament[]) => void;
  onStartFixtureMatch: (tournamentId: string, fixtureId: string, match: Match) => void;
  onResumeMatch: (matchId: string) => void;
  onViewScorecard: (matchId: string) => void;
}

export const TournamentView: React.FC<TournamentViewProps> = ({
  tournaments,
  teams,
  matches,
  onSaveTournaments,
  onStartFixtureMatch,
  onResumeMatch,
  onViewScorecard,
}) => {
  const [selectedId, setSelectedId] = useState<string>(tournaments[0]?.id || '');
  const [showCreate, setShowCreate] = useState(false);
  const [name, setName] = useState('');
  const [format, setFormat] = useState<'T20' | 'T10' | 'T5' | 'ODI' | 'CUSTOM'>('T20');
  const [overs, setOvers] = useState<number>(20);
  const [playersPerSide, setPlayersPerSide] = useState<number>(11);
  const [mode, setMode] = useState<'round_robin' | 'knockout'>('round_robin');
  const [selectedTeamIds, setSelectedTeamIds] = useState<string[]>(
    teams.slice(0, 4).map((t) => t.id)
  );
  const [confirmDeleteId, setConfirmDeleteId] = useState<string | null>(null);

  const active = tournaments.find((t) => t.id === selectedId) || tournaments[0] || null;

  const toggleTeam = (tid: string) => {
    setSelectedTeamIds((prev) =>
      prev.includes(tid) ? prev.filter((x) => x !== tid) : [...prev, tid]
    );
  };

  const handleCreateTournament = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim() || selectedTeamIds.length < 2) return;

    const fixtures: TournamentFixture[] = [];
    if (mode === 'round_robin') {
      let count = 1;
      for (let i = 0; i < selectedTeamIds.length; i++) {
        for (let j = i + 1; j < selectedTeamIds.length; j++) {
          fixtures.push({
            id: createId('fix'),
            round: 1,
            label: `League Match ${count++}`,
            teamAId: selectedTeamIds[i],
            teamBId: selectedTeamIds[j],
            status: 'scheduled',
          });
        }
      }
    } else {
      let count = 1;
      for (let i = 0; i < selectedTeamIds.length - 1; i += 2) {
        fixtures.push({
          id: createId('fix'),
          round: 1,
          label: `Knockout Match ${count++}`,
          teamAId: selectedTeamIds[i],
          teamBId: selectedTeamIds[i + 1],
          status: 'scheduled',
        });
      }
    }

    const now = Date.now();
    const created: Tournament = {
      id: createId('tour'),
      name: name.trim(),
      format,
      oversPerInnings: overs,
      playersPerSide,
      mode,
      teamIds: selectedTeamIds,
      fixtures,
      createdAt: now,
      updatedAt: now,
    };
    const next = [created, ...tournaments];
    onSaveTournaments(next);
    setSelectedId(created.id);
    setName('');
    setShowCreate(false);
  };

  const buildSnapshot = (team: Team): MatchTeamSnapshot => {
    const xi = (
      team.defaultPlayingXI.length > 0
        ? team.defaultPlayingXI
        : team.players.map((p) => p.id)
    ).slice(0, active?.playersPerSide || 11);
    return {
      teamId: team.id,
      name: team.name,
      shortName: team.shortName,
      players: team.players,
      playingXI: xi,
      substitutes: team.players.filter((p) => !xi.includes(p.id)).map((p) => p.id),
      captainId: team.defaultCaptainId,
      keeperId: team.defaultKeeperId,
    };
  };

  const handleLaunchFixture = (fixture: TournamentFixture) => {
    if (!active) return;
    if (fixture.matchId) {
      const existing = matches.find((m) => m.id === fixture.matchId);
      if (existing) {
        if (existing.status === 'completed') onViewScorecard(existing.id);
        else onResumeMatch(existing.id);
        return;
      }
    }
    const tA = teams.find((t) => t.id === fixture.teamAId);
    const tB = teams.find((t) => t.id === fixture.teamBId);
    if (!tA || !tB) return;

    const now = Date.now();
    const match: Match = {
      id: createId('match'),
      title: `${active.name} · ${tA.shortName} vs ${tB.shortName}`,
      format: active.format,
      oversPerInnings: active.oversPerInnings,
      maxBowlerOvers: Math.max(1, Math.floor(active.oversPerInnings / 5)),
      playersPerSide: Math.min(
        active.playersPerSide,
        Math.max(2, Math.min(tA.players.length, tB.players.length))
      ),
      followOnThreshold: 0,
      teams: {
        teamA: buildSnapshot(tA),
        teamB: buildSnapshot(tB),
      },
      toss: { winnerSide: 'teamA', decision: 'bat' },
      innings: [
        {
          inningsNumber: 1,
          battingTeamSide: 'teamA',
          bowlingTeamSide: 'teamB',
          balls: [],
          strikerId: null,
          nonStrikerId: null,
          currentBowlerId: null,
          previousBowlerId: null,
          isDeclared: false,
          isCompleted: false,
        },
      ],
      currentInningsIndex: 0,
      status: 'in_progress',
      tournamentId: active.id,
      fixtureId: fixture.id,
      createdAt: now,
      updatedAt: now,
    };

    onStartFixtureMatch(active.id, fixture.id, match);
  };

  const standings = active ? computeTournamentStandings(active, teams, matches) : [];

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-white/15 pb-4">
        <div>
          <h1 className="font-display text-3xl font-bold text-white">Tournament Mode</h1>
          <p className="text-xs text-neutral-400 mt-1">
            Organize round-robin leagues or knockouts with live points table and Net Run Rate (NRR).
          </p>
        </div>
        <button
          type="button"
          onClick={() => setShowCreate(true)}
          className="min-h-[44px] px-4 rounded-xl bg-white text-black text-sm font-semibold hover:bg-neutral-200 inline-flex items-center gap-2 whitespace-nowrap shrink-0"
        >
          <Plus className="w-4 h-4" />
          <span>New Tournament</span>
        </button>
      </div>

      {showCreate && (
        <form
          onSubmit={handleCreateTournament}
          className="rounded-2xl bg-neutral-950 border border-white/25 p-5 space-y-4"
        >
          <div className="flex items-center justify-between">
            <h2 className="text-base font-bold text-white">Create Tournament</h2>
            <button
              type="button"
              onClick={() => setShowCreate(false)}
              className="min-h-[36px] min-w-[36px] flex items-center justify-center text-neutral-400 hover:text-white"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
            <div className="sm:col-span-2">
              <label className="block text-xs text-neutral-400 mb-1">Tournament Name</label>
              <input
                type="text"
                required
                value={name}
                onChange={(e) => setName(e.target.value)}
                placeholder="e.g. Weekend Premier League"
                className="w-full min-h-[44px] px-3.5 rounded-xl bg-black border border-white/20 text-white text-sm"
              />
            </div>
            <div>
              <label className="block text-xs text-neutral-400 mb-1">Format</label>
              <select
                value={format}
                onChange={(e) => {
                  const val = e.target.value as 'T20' | 'T10' | 'T5' | 'ODI' | 'CUSTOM';
                  setFormat(val);
                  if (val === 'ODI') setOvers(50);
                  else if (val === 'T20') setOvers(20);
                  else if (val === 'T10') setOvers(10);
                  else if (val === 'T5') setOvers(5);
                }}
                className="w-full min-h-[44px] px-3 rounded-xl bg-black border border-white/20 text-white text-sm"
              >
                <option value="T20">T20 (20 Ov)</option>
                <option value="T10">T10 (10 Ov)</option>
                <option value="T5">T5 (5 Ov)</option>
                <option value="ODI">ODI (50 Ov)</option>
                <option value="CUSTOM">Custom Overs</option>
              </select>
            </div>
            <div>
              <label className="block text-xs text-neutral-400 mb-1">Overs & Mode</label>
              <div className="flex gap-2">
                <input
                  type="number"
                  min={1}
                  max={50}
                  value={overs}
                  onChange={(e) => setOvers(Math.max(1, Number(e.target.value)))}
                  className="w-20 min-h-[44px] px-2.5 rounded-xl bg-black border border-white/20 text-white font-mono text-sm"
                />
                <select
                  value={mode}
                  onChange={(e) => setMode(e.target.value as 'round_robin' | 'knockout')}
                  className="flex-1 min-h-[44px] px-2.5 rounded-xl bg-black border border-white/20 text-white text-xs"
                >
                  <option value="round_robin">Round Robin</option>
                  <option value="knockout">Knockout</option>
                </select>
              </div>
            </div>
          </div>

          <div>
            <label className="block text-xs text-neutral-400 mb-2">
              Select Participating Teams ({selectedTeamIds.length} selected, min 2)
            </label>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
              {teams.map((t) => {
                const picked = selectedTeamIds.includes(t.id);
                return (
                  <button
                    key={t.id}
                    type="button"
                    onClick={() => toggleTeam(t.id)}
                    className={`min-h-[42px] px-3 rounded-xl text-xs border text-left truncate transition ${
                      picked
                        ? 'bg-white text-black border-white font-semibold'
                        : 'bg-black text-neutral-300 border-white/15'
                    }`}
                  >
                    {t.name} ({t.shortName})
                  </button>
                );
              })}
            </div>
          </div>

          <div className="flex items-center justify-between pt-2">
            <div className="flex items-center gap-2 text-xs text-neutral-400">
              <span>Players/Side:</span>
              <input
                type="number"
                min={2}
                max={11}
                value={playersPerSide}
                onChange={(e) => setPlayersPerSide(Math.max(2, Math.min(11, Number(e.target.value))))}
                className="w-16 min-h-[36px] px-2 rounded-lg bg-black border border-white/20 text-white font-mono text-xs"
              />
            </div>
            <button
              type="submit"
              disabled={selectedTeamIds.length < 2}
              className="min-h-[44px] px-5 rounded-xl bg-white text-black text-sm font-bold disabled:opacity-40"
            >
              Generate Fixtures
            </button>
          </div>
        </form>
      )}

      {tournaments.length === 0 ? (
        <div className="rounded-2xl bg-neutral-950 border border-dashed border-white/15 p-10 text-center space-y-2">
          <Trophy className="w-7 h-7 text-neutral-500 mx-auto" />
          <p className="text-sm text-neutral-300">No tournaments created yet.</p>
          <p className="text-xs text-neutral-500">
            Create a tournament to auto-generate fixtures and track NRR standings offline.
          </p>
        </div>
      ) : (
        <div className="space-y-6">
          {/* Tournament Selector Tabs */}
          <div className="flex flex-wrap gap-2">
            {tournaments.map((t) => (
              <button
                key={t.id}
                type="button"
                onClick={() => setSelectedId(t.id)}
                className={`min-h-[42px] px-4 rounded-xl text-xs font-semibold border transition ${
                  active?.id === t.id
                    ? 'bg-white text-black border-white'
                    : 'bg-neutral-950 text-neutral-300 border-white/15 hover:border-white/40'
                }`}
              >
                {t.name} ({t.format})
              </button>
            ))}
          </div>

          {active && (
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
              {/* Points Table */}
              <div className="lg:col-span-6 rounded-2xl bg-neutral-950 border border-white/15 overflow-hidden">
                <div className="px-5 py-3.5 border-b border-white/10 flex items-center justify-between">
                  <span className="text-xs font-mono text-neutral-400">POINTS TABLE</span>
                  {confirmDeleteId === active.id ? (
                    <div className="flex items-center gap-2">
                      <button
                        type="button"
                        onClick={() => {
                          const next = tournaments.filter((x) => x.id !== active.id);
                          onSaveTournaments(next);
                          setSelectedId(next[0]?.id || '');
                          setConfirmDeleteId(null);
                        }}
                        className="px-2.5 py-1 rounded bg-white text-black text-xs font-bold"
                      >
                        Delete
                      </button>
                      <button
                        type="button"
                        onClick={() => setConfirmDeleteId(null)}
                        className="text-xs text-neutral-400"
                      >
                        Cancel
                      </button>
                    </div>
                  ) : (
                    <button
                      type="button"
                      onClick={() => setConfirmDeleteId(active.id)}
                      className="text-neutral-400 hover:text-white"
                      aria-label="Delete Tournament"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  )}
                </div>
                <div className="overflow-x-auto">
                  <table className="w-full text-xs text-left">
                    <thead>
                      <tr className="border-b border-white/10 font-mono text-neutral-400">
                        <th className="py-3 px-4">Team</th>
                        <th className="py-3 px-2 text-right">P</th>
                        <th className="py-3 px-2 text-right">W</th>
                        <th className="py-3 px-2 text-right">L</th>
                        <th className="py-3 px-2 text-right">NRR</th>
                        <th className="py-3 px-4 text-right">PTS</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-white/10 font-mono tabular-nums">
                      {standings.map((row, idx) => (
                        <tr key={row.teamId}>
                          <td className="py-3 px-4 font-sans font-medium text-white">
                            {idx + 1}. {row.shortName}
                          </td>
                          <td className="py-3 px-2 text-right text-neutral-300">{row.played}</td>
                          <td className="py-3 px-2 text-right text-neutral-300">{row.won}</td>
                          <td className="py-3 px-2 text-right text-neutral-400">{row.lost}</td>
                          <td className="py-3 px-2 text-right text-neutral-300">
                            {row.nrr >= 0 ? `+${row.nrr.toFixed(3)}` : row.nrr.toFixed(3)}
                          </td>
                          <td className="py-3 px-4 text-right font-bold text-white">
                            {row.points}
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>

              {/* Fixtures */}
              <div className="lg:col-span-6 rounded-2xl bg-neutral-950 border border-white/15 p-5 space-y-3">
                <h3 className="text-xs font-mono text-neutral-400">FIXTURES</h3>
                <div className="space-y-2.5">
                  {active.fixtures.map((fix) => {
                    const tA = teams.find((t) => t.id === fix.teamAId);
                    const tB = teams.find((t) => t.id === fix.teamBId);
                    const linked = fix.matchId ? matches.find((m) => m.id === fix.matchId) : null;

                    return (
                      <div
                        key={fix.id}
                        className="rounded-xl bg-black border border-white/10 p-3.5 flex items-center justify-between gap-3"
                      >
                        <div className="min-w-0">
                          <div className="text-[11px] font-mono text-neutral-400">{fix.label}</div>
                          <div className="text-sm font-semibold text-white truncate">
                            {tA?.name || 'Team A'} vs {tB?.name || 'Team B'}
                          </div>
                          {linked?.result && (
                            <div className="text-xs text-neutral-300 mt-0.5">
                              {linked.result.summary}
                            </div>
                          )}
                        </div>
                        <button
                          type="button"
                          onClick={() => handleLaunchFixture(fix)}
                          className="min-h-[40px] px-3.5 rounded-lg bg-white text-black text-xs font-bold hover:bg-neutral-200 inline-flex items-center gap-1.5 shrink-0"
                        >
                          <Play className="w-3.5 h-3.5 fill-current" />
                          <span>
                            {linked?.status === 'completed'
                              ? 'Scorecard'
                              : linked
                              ? 'Resume'
                              : 'Score'}
                          </span>
                        </button>
                      </div>
                    );
                  })}
                </div>
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  );
};
