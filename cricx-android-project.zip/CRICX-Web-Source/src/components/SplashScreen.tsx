import React, { useEffect } from 'react';
import { CricXLogo } from './CricXLogo';

interface SplashScreenProps {
  onFinish: () => void;
}

export const SplashScreen: React.FC<SplashScreenProps> = ({ onFinish }) => {
  useEffect(() => {
    const timer = window.setTimeout(() => {
      onFinish();
    }, 650);
    return () => window.clearTimeout(timer);
  }, [onFinish]);

  return (
    <button
      type="button"
      onClick={onFinish}
      aria-label="Enter CRIC X"
      className="fixed inset-0 z-50 bg-black text-white flex flex-col items-center justify-center gap-6 cursor-pointer focus:outline-none"
    >
      <div className="flex flex-col items-center gap-5">
        <div className="w-24 h-24 bg-black border border-white/25 rounded-2xl flex items-center justify-center">
          <svg viewBox="0 0 64 64" className="w-16 h-16" aria-hidden="true">
            <line x1="14" y1="14" x2="50" y2="50" stroke="#ffffff" strokeWidth="7" strokeLinecap="square" />
            <line x1="50" y1="14" x2="14" y2="50" stroke="#ffffff" strokeWidth="7" strokeLinecap="square" />
            <circle cx="32" cy="32" r="6" fill="#000000" stroke="#ffffff" strokeWidth="2.5" />
          </svg>
        </div>
        <div className="text-center">
          <h1 className="font-display text-5xl font-bold tracking-[0.18em] text-white">CRIC X</h1>
          <p className="font-mono text-xs tracking-[0.26em] text-neutral-400 mt-2">
            SCAN · SCORE · PLAY
          </p>
        </div>
      </div>
      <div className="sr-only">
        <CricXLogo size="lg" showTagline />
      </div>
    </button>
  );
};
