import React from 'react';
import { Play, Trophy, Users, History, ChevronRight, ArrowUpRight, Download } from 'lucide-react';
import { Match, MatchFormat, Team, Tournament } from '../types/cricket';
import { computeMatchOverview, getFormatDefaults } from '../engine/cricketEngine';

interface HomeViewProps {
  matches: Match[];
  teams: Team[];
  tournaments: Tournament[];
  onStartFormat: (format: MatchFormat) => void;
  onOpenTournament: () => void;
  onResumeMatch: (matchId: string) => void;
  onViewScorecard: (matchId: string) => void;
  onOpenTeams: () => void;
  onOpenHistory: () => void;
}

const FORMAT_ITEMS: Array<{
  format: MatchFormat | 'TOURNAMENT';
  title: string;
  subtitle: string;
}> = [
  { format: 'TEST', title: 'Test Match', subtitle: '4 Innings · 5 Days · Follow-On' },
  { format: 'ODI', title: 'One Day (ODI)', subtitle: '50 Overs · 10 Over Cap' },
  { format: 'T20', title: 'T20', subtitle: '20 Overs · 4 Over Cap' },
  { format: 'T10', title: 'T10', subtitle: '10 Overs · 2 Over Cap' },
  { format: 'T5', title: 'T5', subtitle: '5 Overs · Sprint Format' },
  { format: 'CUSTOM', title: 'Custom Overs', subtitle: '1–99 Overs · Custom XI' },
  { format: 'PRACTICE', title: 'Practice Match', subtitle: 'Flexible Rules · Quick Start' },
  { format: 'TOURNAMENT', title: 'Tournament Mode', subtitle: 'League · Knockout · NRR Table' },
];

export const HomeView: React.FC<HomeViewProps> = ({
  matches,
  teams,
  tournaments,
  onStartFormat,
  onOpenTournament,
  onResumeMatch,
  onViewScorecard,
  onOpenTeams,
  onOpenHistory,
}) => {
  const unfinishedMatches = matches.filter((m) => m.status === 'in_progress');
  const latestUnfinished = unfinishedMatches[0] || null;
  const recentCompleted = matches.filter((m) => m.status === 'completed').slice(0, 3);

  return (
    <div className="space-y-8">
      {/* Hero / Direct Start Strip */}
      <section className="border-b border-white/15 pb-6 flex flex-col md:flex-row md:items-end md:justify-between gap-4">
        <div>
          <p className="text-xs font-mono tracking-[0.2em] text-neutral-400">
            OFFLINE CRICKET SCORING ENGINE
          </p>
          <h1 className="font-display text-4xl sm:text-5xl font-bold tracking-tight text-white mt-1.5 text-balance">
            Score every ball without limits.
          </h1>
          <p className="text-sm text-neutral-400 mt-2 max-w-xl leading-relaxed">
            Instant local scoring for Test, limited-overs, custom, and tournament cricket. Everything saves automatically on your device.
          </p>
        </div>
        <div className="flex flex-wrap items-center gap-3 shrink-0">
          <button
            type="button"
            onClick={() => onStartFormat('T20')}
            className="min-h-[48px] px-5 py-2.5 rounded-xl bg-white text-black text-sm font-semibold hover:bg-neutral-200 active:scale-[0.98] transition inline-flex items-center gap-2 whitespace-nowrap shrink-0"
          >
            <Play className="w-4 h-4 fill-current" />
            <span>Quick T20 Match</span>
          </button>
          <button
            type="button"
            onClick={onOpenTeams}
            className="min-h-[48px] px-4 py-2.5 rounded-xl bg-neutral-900 border border-white/15 text-white text-sm font-medium hover:bg-neutral-800 transition inline-flex items-center gap-2 whitespace-nowrap shrink-0"
          >
            <Users className="w-4 h-4" />
            <span>Manage Teams ({teams.length})</span>
          </button>
        </div>
      </section>

      {/* Unfinished Match Recovery Banner */}
      {latestUnfinished && (() => {
        const overview = computeMatchOverview(latestUnfinished);
        const curInn = latestUnfinished.innings[latestUnfinished.currentInningsIndex];
        const curStats = overview.inningsStats[latestUnfinished.currentInningsIndex];
        const batTeam =
          curInn.battingTeamSide === 'teamA'
            ? latestUnfinished.teams.teamA
            : latestUnfinished.teams.teamB;

        return (
          <section className="rounded-2xl bg-neutral-950 border border-white/25 p-5 sm:p-6">
            <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between gap-5">
              <div className="space-y-1.5">
                <div className="flex items-center gap-2 text-xs font-mono text-neutral-300">
                  <span>UNFINISHED MATCH</span>
                  <span aria-hidden="true">·</span>
                  <span>{getFormatDefaults(latestUnfinished.format).label}</span>
                  {latestUnfinished.testState && (
                    <>
                      <span aria-hidden="true">·</span>
                      <span>
                        Day {latestUnfinished.testState.day} ({latestUnfinished.testState.session})
                      </span>
                    </>
                  )}
                </div>
                <h2 className="text-xl sm:text-2xl font-semibold text-white">
                  {latestUnfinished.teams.teamA.name} vs {latestUnfinished.teams.teamB.name}
                </h2>
                <div className="flex flex-wrap items-baseline gap-x-4 gap-y-1 pt-1">
                  <span className="font-mono text-2xl font-bold tabular-nums text-white">
                    {batTeam.shortName} {curStats.totalRuns}/{curStats.wickets}
                  </span>
                  <span className="font-mono text-sm tabular-nums text-neutral-400">
                    ({curStats.oversDisplay} ov)
                  </span>
                  <span className="text-sm text-neutral-300">{overview.statusLine}</span>
                </div>
              </div>
              <div className="flex flex-wrap items-center gap-3 shrink-0">
                <button
                  type="button"
                  onClick={() => onResumeMatch(latestUnfinished.id)}
                  className="min-h-[48px] px-5 py-2.5 rounded-xl bg-white text-black text-sm font-semibold hover:bg-neutral-200 active:scale-[0.98] transition inline-flex items-center gap-2 whitespace-nowrap"
                >
                  <Play className="w-4 h-4 fill-current" />
                  <span>Resume Scoring</span>
                </button>
                <button
                  type="button"
                  onClick={() => onViewScorecard(latestUnfinished.id)}
                  className="min-h-[48px] px-4 py-2.5 rounded-xl border border-white/20 text-white text-sm font-medium hover:bg-white/10 transition whitespace-nowrap"
                >
                  Scorecard
                </button>
              </div>
            </div>
            {unfinishedMatches.length > 1 && (
              <div className="mt-4 pt-3 border-t border-white/10 flex items-center justify-between text-xs text-neutral-400">
                <span>{unfinishedMatches.length - 1} more unfinished match saved locally</span>
                <button
                  type="button"
                  onClick={onOpenHistory}
                  className="text-white hover:underline font-medium"
                >
                  View all in History
                </button>
              </div>
            )}
          </section>
        );
      })()}

      {/* All 8 Match Formats */}
      <section className="space-y-4">
        <div className="flex items-center justify-between">
          <h2 className="text-lg font-semibold text-white">Start a Match</h2>
          <span className="text-xs text-neutral-400">Select format to configure teams</span>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
          {FORMAT_ITEMS.map((item) => {
            const isTourney = item.format === 'TOURNAMENT';
            return (
              <button
                key={item.format}
                type="button"
                onClick={() =>
                  isTourney
                    ? onOpenTournament()
                    : onStartFormat(item.format as MatchFormat)
                }
                className="group text-left rounded-2xl bg-neutral-950 border border-white/15 hover:border-white/50 p-4 min-h-[96px] flex flex-col justify-between transition active:scale-[0.99]"
              >
                <div className="flex items-start justify-between gap-2">
                  <span className="text-base font-semibold text-white group-hover:text-white">
                    {item.title}
                  </span>
                  {isTourney ? (
                    <Trophy className="w-4 h-4 text-neutral-400 group-hover:text-white shrink-0 mt-0.5" />
                  ) : (
                    <ArrowUpRight className="w-4 h-4 text-neutral-500 group-hover:text-white shrink-0 mt-0.5 transition-transform group-hover:translate-x-0.5 group-hover:-translate-y-0.5" />
                  )}
                </div>
                <p className="text-xs text-neutral-400 mt-3">{item.subtitle}</p>
              </button>
            );
          })}
        </div>
      </section>

      {/* Bottom 2-column summary: Recent Matches + Quick Overview */}
      <section className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2 rounded-2xl bg-neutral-950 border border-white/15 p-5 space-y-4">
          <div className="flex items-center justify-between">
            <h2 className="text-base font-semibold text-white">Recent Completed Matches</h2>
            <button
              type="button"
              onClick={onOpenHistory}
              className="min-h-[36px] inline-flex items-center gap-1 text-xs text-neutral-300 hover:text-white transition"
            >
              <span>All History</span>
              <ChevronRight className="w-4 h-4" />
            </button>
          </div>

          {recentCompleted.length === 0 ? (
            <div className="py-8 text-center border border-dashed border-white/15 rounded-xl">
              <History className="w-6 h-6 text-neutral-500 mx-auto mb-2" />
              <p className="text-sm text-neutral-400">No completed matches yet.</p>
              <p className="text-xs text-neutral-500 mt-1">
                Start any format above to record your first scorecard.
              </p>
            </div>
          ) : (
            <div className="divide-y divide-white/10">
              {recentCompleted.map((m) => {
                const ov = computeMatchOverview(m);
                return (
                  <button
                    key={m.id}
                    type="button"
                    onClick={() => onViewScorecard(m.id)}
                    className="w-full py-3.5 text-left flex flex-col sm:flex-row sm:items-center justify-between gap-2 hover:bg-white/[0.03] px-2 -mx-2 rounded-lg transition"
                  >
                    <div>
                      <div className="flex items-center gap-2 text-xs text-neutral-400">
                        <span>{getFormatDefaults(m.format).label}</span>
                        <span aria-hidden="true">·</span>
                        <span>{new Date(m.updatedAt).toLocaleDateString()}</span>
                      </div>
                      <p className="text-sm font-medium text-white mt-0.5">
                        {m.teams.teamA.shortName} vs {m.teams.teamB.shortName}
                      </p>
                      <p className="text-xs text-neutral-300 mt-0.5">
                        {m.result?.summary || ov.statusLine}
                      </p>
                    </div>
                    <div className="font-mono text-xs tabular-nums text-neutral-300 text-left sm:text-right shrink-0">
                      {m.innings.map((inn, idx) => {
                        const t =
                          inn.battingTeamSide === 'teamA'
                            ? m.teams.teamA.shortName
                            : m.teams.teamB.shortName;
                        const s = ov.inningsStats[idx];
                        return (
                          <div key={inn.inningsNumber}>
                            {t} {s.totalRuns}/{s.wickets} ({s.oversDisplay})
                          </div>
                        );
                      })}
                    </div>
                  </button>
                );
              })}
            </div>
          )}
        </div>

        <div className="rounded-2xl bg-neutral-950 border border-white/15 p-5 flex flex-col justify-between gap-5">
          <div className="space-y-4">
            <h2 className="text-base font-semibold text-white">Local Vault</h2>
            <div className="grid grid-cols-3 gap-3 text-center">
              <div className="rounded-xl bg-black border border-white/10 p-3">
                <div className="font-mono text-2xl font-bold tabular-nums text-white">
                  {teams.length}
                </div>
                <div className="text-xs text-neutral-400 mt-1">Teams</div>
              </div>
              <div className="rounded-xl bg-black border border-white/10 p-3">
                <div className="font-mono text-2xl font-bold tabular-nums text-white">
                  {matches.length}
                </div>
                <div className="text-xs text-neutral-400 mt-1">Matches</div>
              </div>
              <div className="rounded-xl bg-black border border-white/10 p-3">
                <div className="font-mono text-2xl font-bold tabular-nums text-white">
                  {tournaments.length}
                </div>
                <div className="text-xs text-neutral-400 mt-1">Events</div>
              </div>
            </div>
            <p className="text-xs text-neutral-400 leading-relaxed">
              No login, no internet, and no cloud sync required. All squads, scorecards, and tournament tables persist directly in device storage.
            </p>
          </div>
          <div className="space-y-2.5">
            <div className="grid grid-cols-2 gap-2.5">
              <button
                type="button"
                onClick={onOpenTeams}
                className="min-h-[44px] rounded-xl border border-white/20 text-white text-xs font-medium hover:bg-white/10 transition"
              >
                Squads
              </button>
              <button
                type="button"
                onClick={onOpenTournament}
                className="min-h-[44px] rounded-xl bg-white text-black text-xs font-semibold hover:bg-neutral-200 transition"
              >
                Tournaments
              </button>
            </div>
            <a
              href="./cricx-android-project.zip"
              download="cricx-android-project.zip"
              className="w-full min-h-[44px] px-4 rounded-xl border border-white/25 text-white text-xs font-semibold hover:bg-white/10 inline-flex items-center justify-center gap-2 transition"
            >
              <Download className="w-4 h-4" />
              <span>Download Project & Android ZIP</span>
            </a>
          </div>
        </div>
      </section>
    </div>
  );
};
