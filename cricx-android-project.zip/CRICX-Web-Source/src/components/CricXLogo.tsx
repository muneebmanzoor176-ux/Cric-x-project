import React from 'react';

interface CricXLogoProps {
  size?: 'sm' | 'md' | 'lg';
  showTagline?: boolean;
}

export const CricXLogo: React.FC<CricXLogoProps> = ({ size = 'md', showTagline = false }) => {
  const boxSize = size === 'sm' ? 'w-8 h-8' : size === 'lg' ? 'w-20 h-20' : 'w-10 h-10';
  const textSize =
    size === 'sm' ? 'text-xl' : size === 'lg' ? 'text-5xl' : 'text-2xl';

  return (
    <div className="inline-flex items-center gap-3 select-none">
      <div
        className={`${boxSize} bg-black border border-white/25 rounded-xl flex items-center justify-center shrink-0`}
      >
        <svg viewBox="0 0 64 64" className="w-[72%] h-[72%]" aria-hidden="true">
          <line x1="14" y1="14" x2="50" y2="50" stroke="#ffffff" strokeWidth="7" strokeLinecap="square" />
          <line x1="50" y1="14" x2="14" y2="50" stroke="#ffffff" strokeWidth="7" strokeLinecap="square" />
          <circle cx="32" cy="32" r="6" fill="#000000" stroke="#ffffff" strokeWidth="2.5" />
        </svg>
      </div>
      <div className="flex flex-col">
        <span
          className={`${textSize} font-display font-bold tracking-[0.14em] text-white leading-none whitespace-nowrap`}
        >
          CRIC X
        </span>
        {showTagline && (
          <span className="text-[11px] font-mono tracking-[0.22em] text-neutral-400 mt-1.5 whitespace-nowrap">
            SCAN · SCORE · PLAY
          </span>
        )}
      </div>
    </div>
  );
};
