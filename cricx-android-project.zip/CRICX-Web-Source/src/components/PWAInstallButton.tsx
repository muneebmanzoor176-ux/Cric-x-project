import React, { useState } from 'react';
import { Download, Smartphone, X } from 'lucide-react';
import { usePWAInstall } from '../hooks/usePWAInstall';

interface PWAInstallButtonProps {
  onOpenGuide?: () => void;
}

export const PWAInstallButton: React.FC<PWAInstallButtonProps> = ({ onOpenGuide }) => {
  const { isInstallable, isInstalled, isIOS, install } = usePWAInstall();
  const [showIOSGuide, setShowIOSGuide] = useState(false);

  if (isInstalled) {
    return null;
  }

  if (isInstallable) {
    return (
      <button
        type="button"
        onClick={install}
        className="inline-flex items-center justify-center gap-2 min-h-[44px] px-4 py-2 rounded-lg bg-white text-black text-xs font-semibold hover:bg-neutral-200 active:scale-[0.98] transition whitespace-nowrap shrink-0"
      >
        <Download className="w-4 h-4" />
        <span>Install App</span>
      </button>
    );
  }

  if (isIOS) {
    return (
      <>
        <button
          type="button"
          onClick={() => setShowIOSGuide(true)}
          className="inline-flex items-center justify-center gap-2 min-h-[44px] px-3.5 py-2 rounded-lg border border-white/25 text-white text-xs font-medium hover:bg-white/10 transition whitespace-nowrap shrink-0"
        >
          <Smartphone className="w-4 h-4" />
          <span>Install</span>
        </button>

        {showIOSGuide && (
          <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 p-4">
            <div className="w-full max-w-sm rounded-2xl bg-neutral-950 border border-white/20 p-6 text-white">
              <div className="flex items-center justify-between mb-3">
                <h3 className="text-base font-semibold">Install CRIC X on iOS</h3>
                <button
                  type="button"
                  onClick={() => setShowIOSGuide(false)}
                  className="min-h-[44px] min-w-[44px] flex items-center justify-center text-neutral-400 hover:text-white"
                  aria-label="Close"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>
              <p className="text-sm text-neutral-300 leading-relaxed">
                1. Tap the Share icon in Safari.
                <br />
                2. Scroll down and select Add to Home Screen.
              </p>
              <button
                type="button"
                onClick={() => setShowIOSGuide(false)}
                className="mt-5 w-full min-h-[44px] rounded-lg bg-white text-black text-sm font-semibold hover:bg-neutral-200 transition"
              >
                Done
              </button>
            </div>
          </div>
        )}
      </>
    );
  }

  if (onOpenGuide) {
    return (
      <button
        type="button"
        onClick={onOpenGuide}
        className="inline-flex items-center justify-center gap-2 min-h-[44px] px-3.5 py-2 rounded-lg border border-white/20 text-white text-xs font-medium hover:bg-white/10 transition whitespace-nowrap shrink-0"
      >
        <Smartphone className="w-4 h-4" />
        <span>Offline App</span>
      </button>
    );
  }

  return null;
};
