import React, { useState } from 'react';
import { ArrowLeft, Share2, Play, Copy, Check } from 'lucide-react';
import { BallEvent, ExtraType, Match } from '../types/cricket';
import {
  computeMatchOverview,
  editBallInMatch,
  formatBallBadge,
  generateShareableScorecard,
  getFormatDefaults,
  getTeamSnapshot,
} from '../engine/cricketEngine';

interface ScorecardViewProps {
  match: Match;
  onUpdateMatch: (match: Match) => void;
  onResumeScoring?: () => void;
  onBack: () => void;
}

export const ScorecardView: React.FC<ScorecardViewProps> = ({
  match,
  onUpdateMatch,
  onResumeScoring,
  onBack,
}) => {
  const [selectedInningsIdx, setSelectedInningsIdx] = useState<number>(
    match.currentInningsIndex
  );
  const [copied, setCopied] = useState(false);
  const [editingBall, setEditingBall] = useState<BallEvent | null>(null);
  const [editRuns, setEditRuns] = useState(0);
  const [editExtraType, setEditExtraType] = useState<ExtraType>('none');
  const [editExtraRuns, setEditExtraRuns] = useState(0);

  const overview = computeMatchOverview(match);
  const inn = match.innings[selectedInningsIdx] || match.innings[0];
  const stats = overview.inningsStats[selectedInningsIdx] || overview.inningsStats[0];
  const batTeam = getTeamSnapshot(match, inn.battingTeamSide);

  // Group balls by over for Over-by-Over log
  const oversMap = new Map<number, BallEvent[]>();
  inn.balls.forEach((b) => {
    const arr = oversMap.get(b.overNumber) || [];
    arr.push(b);
    oversMap.set(b.overNumber, arr);
  });
  const overEntries = Array.from(oversMap.entries()).sort((a, b) => b[0] - a[0]);

  const handleShare = async () => {
    const text = generateShareableScorecard(match);
    try {
      if (navigator.share) {
        await navigator.share({ title: match.title, text });
      } else {
        await navigator.clipboard.writeText(text);
        setCopied(true);
        window.setTimeout(() => setCopied(false), 2000);
      }
    } catch {
      await navigator.clipboard.writeText(text);
      setCopied(true);
      window.setTimeout(() => setCopied(false), 2000);
    }
  };

  const handleCopy = async () => {
    const text = generateShareableScorecard(match);
    await navigator.clipboard.writeText(text);
    setCopied(true);
    window.setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="space-y-6 pb-8">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-white/15 pb-4">
        <div className="flex items-center gap-3">
          <button
            type="button"
            onClick={onBack}
            className="min-h-[44px] min-w-[44px] rounded-xl border border-white/15 flex items-center justify-center text-white hover:bg-white/10"
            aria-label="Back"
          >
            <ArrowLeft className="w-5 h-5" />
          </button>
          <div>
            <div className="text-xs font-mono text-neutral-400">
              {getFormatDefaults(match.format).label} · {new Date(match.createdAt).toLocaleDateString()}
            </div>
            <h1 className="font-display text-2xl sm:text-3xl font-bold text-white">
              {match.teams.teamA.name} vs {match.teams.teamB.name}
            </h1>
            <p className="text-xs sm:text-sm text-neutral-300 mt-0.5">
              {match.result?.summary || overview.statusLine}
            </p>
          </div>
        </div>

        <div className="flex flex-wrap items-center gap-2 shrink-0">
          {match.status === 'in_progress' && onResumeScoring && (
            <button
              type="button"
              onClick={onResumeScoring}
              className="min-h-[44px] px-4 rounded-xl bg-white text-black text-xs font-bold hover:bg-neutral-200 inline-flex items-center gap-1.5"
            >
              <Play className="w-3.5 h-3.5 fill-current" />
              <span>Resume Live</span>
            </button>
          )}
          <button
            type="button"
            onClick={handleCopy}
            className="min-h-[44px] px-3.5 rounded-xl border border-white/20 text-white text-xs font-medium hover:bg-white/10 inline-flex items-center gap-1.5"
          >
            {copied ? <Check className="w-4 h-4" /> : <Copy className="w-4 h-4" />}
            <span>{copied ? 'Copied' : 'Copy'}</span>
          </button>
          <button
            type="button"
            onClick={handleShare}
            className="min-h-[44px] px-4 rounded-xl border border-white/20 text-white text-xs font-medium hover:bg-white/10 inline-flex items-center gap-1.5"
          >
            <Share2 className="w-4 h-4" />
            <span>Share</span>
          </button>
        </div>
      </div>

      {/* Innings Tabs */}
      <div className="flex flex-wrap gap-2">
        {match.innings.map((item, idx) => {
          const t = getTeamSnapshot(match, item.battingTeamSide);
          const s = overview.inningsStats[idx];
          const active = idx === selectedInningsIdx;
          return (
            <button
              key={item.inningsNumber}
              type="button"
              onClick={() => setSelectedInningsIdx(idx)}
              className={`min-h-[44px] px-4 py-2 rounded-xl border text-left transition ${
                active
                  ? 'bg-white text-black border-white'
                  : 'bg-neutral-950 text-white border-white/15 hover:border-white/40'
              }`}
            >
              <div className="text-xs font-semibold">
                {t.shortName} · {item.inningsNumber}
                {item.inningsNumber === 1 ? 'st' : item.inningsNumber === 2 ? 'nd' : item.inningsNumber === 3 ? 'rd' : 'th'} Inn
              </div>
              <div
                className={`font-mono text-xs tabular-nums ${
                  active ? 'text-neutral-800' : 'text-neutral-400'
                }`}
              >
                {s.totalRuns}/{s.wickets}
                {item.isDeclared ? 'd' : ''} ({s.oversDisplay})
              </div>
            </button>
          );
        })}
      </div>

      {/* Summary Banner for Selected Innings */}
      <div className="rounded-2xl bg-neutral-950 border border-white/20 p-5 flex flex-wrap items-baseline justify-between gap-4">
        <div>
          <h2 className="text-lg font-bold text-white">{batTeam.name} Innings</h2>
          <p className="text-xs text-neutral-400 mt-0.5">
            Run Rate: {stats.runRate.toFixed(2)}
            {overview.requiredRunRate !== null && selectedInningsIdx === match.currentInningsIndex
              ? ` · Required RR: ${overview.requiredRunRate.toFixed(2)}`
              : ''}
          </p>
        </div>
        <div className="font-mono text-3xl font-bold tabular-nums text-white">
          {stats.totalRuns}/{stats.wickets}
          {inn.isDeclared ? ' dec' : ''}{' '}
          <span className="text-base font-normal text-neutral-400">
            ({stats.oversDisplay} ov)
          </span>
        </div>
      </div>

      {/* Batting Table */}
      <div className="rounded-2xl bg-neutral-950 border border-white/15 overflow-hidden">
        <div className="px-5 py-3 border-b border-white/10 text-xs font-mono text-neutral-400">
          BATTING
        </div>
        <div className="overflow-x-auto">
          <table className="w-full text-sm text-left">
            <thead>
              <tr className="border-b border-white/10 text-xs font-mono text-neutral-400">
                <th className="py-3 px-5 font-medium">Batter</th>
                <th className="py-3 px-3 font-medium text-right">R</th>
                <th className="py-3 px-3 font-medium text-right">B</th>
                <th className="py-3 px-3 font-medium text-right">4s</th>
                <th className="py-3 px-3 font-medium text-right">6s</th>
                <th className="py-3 px-5 font-medium text-right">SR</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-white/10">
              {stats.batters.map((b) => (
                <tr key={b.playerId}>
                  <td className="py-3 px-5">
                    <div className="font-medium text-white">
                      {b.name}
                      {b.isCaptain ? ' (c)' : ''}
                      {b.isKeeper ? ' (wk)' : ''}
                    </div>
                    <div className="text-xs text-neutral-400 mt-0.5">{b.dismissalText}</div>
                  </td>
                  <td className="py-3 px-3 text-right font-mono font-bold tabular-nums text-white">
                    {b.runs}
                  </td>
                  <td className="py-3 px-3 text-right font-mono tabular-nums text-neutral-300">
                    {b.balls}
                  </td>
                  <td className="py-3 px-3 text-right font-mono tabular-nums text-neutral-400">
                    {b.fours}
                  </td>
                  <td className="py-3 px-3 text-right font-mono tabular-nums text-neutral-400">
                    {b.sixes}
                  </td>
                  <td className="py-3 px-5 text-right font-mono tabular-nums text-neutral-300">
                    {b.strikeRate.toFixed(1)}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        <div className="px-5 py-3 border-t border-white/10 flex flex-wrap items-center justify-between gap-2 text-xs text-neutral-300">
          <span>
            Extras: <strong className="text-white font-mono">{stats.extras.total}</strong> (b{' '}
            {stats.extras.byes}, lb {stats.extras.legByes}, w {stats.extras.wides}, nb{' '}
            {stats.extras.noBalls})
          </span>
          {stats.didNotBat.length > 0 && (
            <span className="text-neutral-400">
              Yet to bat: {stats.didNotBat.map((p) => p.name).join(', ')}
            </span>
          )}
        </div>
      </div>

      {/* Bowling Table */}
      <div className="rounded-2xl bg-neutral-950 border border-white/15 overflow-hidden">
        <div className="px-5 py-3 border-b border-white/10 text-xs font-mono text-neutral-400">
          BOWLING
        </div>
        <div className="overflow-x-auto">
          <table className="w-full text-sm text-left">
            <thead>
              <tr className="border-b border-white/10 text-xs font-mono text-neutral-400">
                <th className="py-3 px-5 font-medium">Bowler</th>
                <th className="py-3 px-3 font-medium text-right">O</th>
                <th className="py-3 px-3 font-medium text-right">M</th>
                <th className="py-3 px-3 font-medium text-right">R</th>
                <th className="py-3 px-3 font-medium text-right">W</th>
                <th className="py-3 px-5 font-medium text-right">ECO</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-white/10">
              {stats.bowlers.map((bw) => (
                <tr key={bw.playerId}>
                  <td className="py-3 px-5 font-medium text-white">{bw.name}</td>
                  <td className="py-3 px-3 text-right font-mono tabular-nums text-neutral-300">
                    {bw.oversDisplay}
                  </td>
                  <td className="py-3 px-3 text-right font-mono tabular-nums text-neutral-400">
                    {bw.maidens}
                  </td>
                  <td className="py-3 px-3 text-right font-mono tabular-nums text-neutral-300">
                    {bw.runs}
                  </td>
                  <td className="py-3 px-3 text-right font-mono font-bold tabular-nums text-white">
                    {bw.wickets}
                  </td>
                  <td className="py-3 px-5 text-right font-mono tabular-nums text-neutral-300">
                    {bw.economy.toFixed(2)}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Fall of Wickets & Partnerships */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-5">
        <div className="rounded-2xl bg-neutral-950 border border-white/15 p-5 space-y-3">
          <h3 className="text-xs font-mono text-neutral-400">FALL OF WICKETS</h3>
          {stats.fallOfWickets.length === 0 ? (
            <p className="text-xs text-neutral-500">No wickets fallen in this innings.</p>
          ) : (
            <div className="flex flex-wrap gap-x-4 gap-y-2 text-xs text-neutral-200 font-mono">
              {stats.fallOfWickets.map((f) => (
                <span key={f.wicketNumber}>
                  <strong className="text-white">
                    {f.wicketNumber}-{f.runs}
                  </strong>{' '}
                  ({f.playerName}, {f.oversDisplay} ov)
                </span>
              ))}
            </div>
          )}
        </div>

        <div className="rounded-2xl bg-neutral-950 border border-white/15 p-5 space-y-3">
          <h3 className="text-xs font-mono text-neutral-400">PARTNERSHIPS</h3>
          {stats.partnerships.length === 0 ? (
            <p className="text-xs text-neutral-500">No partnership data yet.</p>
          ) : (
            <div className="space-y-2 text-xs">
              {stats.partnerships.map((p) => (
                <div
                  key={p.wicketIndex}
                  className="flex items-center justify-between gap-2 border-b border-white/5 pb-1.5 last:border-none"
                >
                  <span className="text-neutral-300 truncate">
                    {p.wicketIndex}. {p.batter1Name} & {p.batter2Name}
                    {p.isCurrent ? ' *' : ''}
                  </span>
                  <span className="font-mono font-semibold tabular-nums text-white shrink-0">
                    {p.runs} ({p.balls}b)
                  </span>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>

      {/* Over-by-Over Ball Log (Editable) */}
      <div className="rounded-2xl bg-neutral-950 border border-white/15 p-5 space-y-3">
        <div className="flex items-center justify-between">
          <h3 className="text-xs font-mono text-neutral-400">OVER-BY-OVER LOG (TAP BALL TO EDIT)</h3>
        </div>
        {overEntries.length === 0 ? (
          <p className="text-xs text-neutral-500">No balls bowled yet.</p>
        ) : (
          <div className="space-y-2.5">
            {overEntries.map(([overNum, balls]) => {
              const overRuns = balls.reduce((acc, b) => acc + b.runsOffBat + b.extraRuns, 0);
              return (
                <div
                  key={overNum}
                  className="flex flex-wrap items-center justify-between gap-3 py-2 border-b border-white/10 last:border-none"
                >
                  <div className="flex items-center gap-3">
                    <span className="font-mono text-xs text-neutral-400 w-14">
                      Ov {overNum + 1}
                    </span>
                    <div className="flex flex-wrap gap-1.5">
                      {balls.map((b) => (
                        <button
                          key={b.id}
                          type="button"
                          onClick={() => {
                            setEditingBall(b);
                            setEditRuns(b.runsOffBat);
                            setEditExtraType(b.extraType);
                            setEditExtraRuns(b.extraRuns);
                          }}
                          className={`min-w-[30px] h-7 px-1.5 rounded-md font-mono text-xs border ${
                            b.wicket || b.runsOffBat >= 4
                              ? 'bg-white text-black border-white font-bold'
                              : 'bg-black text-white border-white/20'
                          }`}
                        >
                          {formatBallBadge(b)}
                        </button>
                      ))}
                    </div>
                  </div>
                  <span className="font-mono text-xs text-neutral-300 tabular-nums">
                    {overRuns} runs
                  </span>
                </div>
              );
            })}
          </div>
        )}
      </div>

      {editingBall && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/85 p-4">
          <div className="w-full max-w-sm rounded-2xl bg-neutral-950 border border-white/25 p-6 space-y-4">
            <h3 className="text-base font-bold text-white">
              Edit Ball ({editingBall.overNumber}.{editingBall.ballInOver})
            </h3>
            <div className="grid grid-cols-3 gap-1.5">
              {(['none', 'wide', 'noball', 'bye', 'legbye'] as ExtraType[]).map((et) => (
                <button
                  key={et}
                  type="button"
                  onClick={() => {
                    setEditExtraType(et);
                    if (et === 'none') setEditExtraRuns(0);
                    else if (editExtraRuns === 0) setEditExtraRuns(1);
                  }}
                  className={`min-h-[38px] rounded-lg text-xs border capitalize ${
                    editExtraType === et
                      ? 'bg-white text-black border-white font-semibold'
                      : 'bg-black text-neutral-300 border-white/15'
                  }`}
                >
                  {et}
                </button>
              ))}
            </div>
            <div>
              <label className="block text-xs text-neutral-400 mb-1.5">Runs Off Bat</label>
              <div className="grid grid-cols-7 gap-1">
                {[0, 1, 2, 3, 4, 5, 6].map((r) => (
                  <button
                    key={r}
                    type="button"
                    onClick={() => setEditRuns(r)}
                    className={`min-h-[38px] rounded-lg font-mono text-xs border ${
                      editRuns === r
                        ? 'bg-white text-black border-white font-bold'
                        : 'bg-black text-white border-white/15'
                    }`}
                  >
                    {r}
                  </button>
                ))}
              </div>
            </div>
            {editExtraType !== 'none' && (
              <input
                type="number"
                min={1}
                max={10}
                value={editExtraRuns}
                onChange={(e) => setEditExtraRuns(Math.max(1, Number(e.target.value)))}
                className="w-full min-h-[40px] px-3 rounded-xl bg-black border border-white/20 text-white font-mono text-sm"
              />
            )}
            <div className="flex justify-end gap-2">
              <button
                type="button"
                onClick={() => setEditingBall(null)}
                className="min-h-[40px] px-4 rounded-xl border border-white/20 text-white text-xs"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={() => {
                  const updated = editBallInMatch(match, selectedInningsIdx, editingBall.id, {
                    runsOffBat: editRuns,
                    extraType: editExtraType,
                    extraRuns: editExtraRuns,
                  });
                  onUpdateMatch(updated);
                  setEditingBall(null);
                }}
                className="min-h-[40px] px-4 rounded-xl bg-white text-black text-xs font-bold"
              >
                Save
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
