import React, { useState } from 'react';
import {
  ArrowLeft,
  RotateCcw,
  ArrowLeftRight,
  ClipboardList,
  Share2,
  Edit3,
  Check,
  X,
} from 'lucide-react';
import {
  BallEvent,
  ExtraType,
  Match,
  TestSessionName,
  WicketKind,
} from '../types/cricket';
import {
  applyBallToMatch,
  computeMatchOverview,
  declareCurrentInnings,
  drawTestMatch,
  editBallInMatch,
  formatBallBadge,
  generateShareableScorecard,
  getFormatDefaults,
  getPlayerName,
  getTeamSnapshot,
  startNextInnings,
  undoLastBallInMatch,
} from '../engine/cricketEngine';

interface LiveScoringViewProps {
  match: Match;
  onUpdateMatch: (match: Match) => void;
  onOpenScorecard: () => void;
  onExit: () => void;
}

export const LiveScoringView: React.FC<LiveScoringViewProps> = ({
  match,
  onUpdateMatch,
  onOpenScorecard,
  onExit,
}) => {
  const overview = computeMatchOverview(match);
  const innIdx = match.currentInningsIndex;
  const inn = match.innings[innIdx];
  const stats = overview.inningsStats[innIdx];
  const battingTeam = getTeamSnapshot(match, inn.battingTeamSide);
  const bowlingTeam = getTeamSnapshot(match, inn.bowlingTeamSide);

  // Sub-modals & sheets
  const [extraSheet, setExtraSheet] = useState<ExtraType | null>(null);
  const [wicketModalOpen, setWicketModalOpen] = useState(false);
  const [wicketKind, setWicketKind] = useState<WicketKind>('caught');
  const [wicketDismissedId, setWicketDismissedId] = useState<string>('');
  const [wicketFielderId, setWicketFielderId] = useState<string>('');
  const [wicketRunsOnBall, setWicketRunsOnBall] = useState<number>(0);

  // Opening / replacement selectors
  const [openStriker, setOpenStriker] = useState<string>(
    battingTeam.playingXI[0] || battingTeam.players[0]?.id || ''
  );
  const [openNonStriker, setOpenNonStriker] = useState<string>(
    battingTeam.playingXI[1] || battingTeam.players[1]?.id || ''
  );
  const [openBowler, setOpenBowler] = useState<string>(
    bowlingTeam.playingXI[bowlingTeam.playingXI.length - 1] ||
      bowlingTeam.players[0]?.id ||
      ''
  );
  const [manualBowlerOpen, setManualBowlerOpen] = useState(false);

  // Ball edit modal
  const [editModalOpen, setEditModalOpen] = useState(false);
  const [editingBall, setEditingBall] = useState<BallEvent | null>(null);
  const [editRunsOffBat, setEditRunsOffBat] = useState<number>(0);
  const [editExtraType, setEditExtraType] = useState<ExtraType>('none');
  const [editExtraRuns, setEditExtraRuns] = useState<number>(0);

  // Test controls confirm
  const [confirmAction, setConfirmAction] = useState<'declare' | 'draw' | null>(null);
  const [shareFeedback, setShareFeedback] = useState<string>('');

  const battingPool = battingTeam.players.filter((p) =>
    battingTeam.playingXI.length > 0 ? battingTeam.playingXI.includes(p.id) : true
  );
  const bowlingPool = bowlingTeam.players.filter((p) =>
    bowlingTeam.playingXI.length > 0 ? bowlingTeam.playingXI.includes(p.id) : true
  );

  const strikerStats = stats.batters.find((b) => b.playerId === inn.strikerId);
  const nonStrikerStats = stats.batters.find((b) => b.playerId === inn.nonStrikerId);
  const currentBowlerStats = stats.bowlers.find((bw) => bw.playerId === inn.currentBowlerId);

  const needsOpening =
    !inn.isCompleted && (!inn.strikerId || !inn.nonStrikerId) && inn.balls.length === 0;
  const needsNewBatter = !inn.isCompleted && !needsOpening && Boolean(inn.needsNewBatter);
  const needsNewBowler =
    !inn.isCompleted && !needsOpening && !needsNewBatter && (Boolean(inn.needsNewBowler) || !inn.currentBowlerId);

  // Available batters who are not out and not currently at the crease
  const availableBatters = battingPool.filter((p) => {
    if (p.id === inn.strikerId || p.id === inn.nonStrikerId) return false;
    const bStat = stats.batters.find((b) => b.playerId === p.id);
    if (!bStat) return true;
    if (bStat.isRetiredHurt && !bStat.isOut) return true;
    return !bStat.isOut;
  });

  // Available bowlers respecting consecutive-over & max-over rules
  const availableBowlers = bowlingPool.filter((p) => {
    if (inn.previousBowlerId && p.id === inn.previousBowlerId && bowlingPool.length > 1) {
      return false;
    }
    if (match.maxBowlerOvers !== null) {
      const bwStat = stats.bowlers.find((bw) => bw.playerId === p.id);
      if (bwStat && Math.floor(bwStat.legalBalls / 6) >= match.maxBowlerOvers) {
        return false;
      }
    }
    return true;
  });

  const handleScoreRun = (runs: number) => {
    if (inn.isCompleted || needsOpening || needsNewBatter || needsNewBowler) return;
    const updated = applyBallToMatch(match, {
      runsOffBat: runs,
      extraType: 'none',
      extraRuns: 0,
    });
    onUpdateMatch(updated);
  };

  const handleScoreExtra = (
    extraType: ExtraType,
    extraRuns: number,
    runsOffBat = 0
  ) => {
    if (inn.isCompleted || needsOpening || needsNewBatter || needsNewBowler) return;
    const updated = applyBallToMatch(match, {
      runsOffBat,
      extraType,
      extraRuns,
    });
    onUpdateMatch(updated);
    setExtraSheet(null);
  };

  const handleConfirmWicket = () => {
    const dismissedId = wicketDismissedId || inn.strikerId || '';
    if (!dismissedId) return;
    const updated = applyBallToMatch(match, {
      runsOffBat: wicketKind === 'runout' ? wicketRunsOnBall : 0,
      extraType: 'none',
      extraRuns: 0,
      wicket: {
        kind: wicketKind,
        dismissedBatsmanId: dismissedId,
        fielderId: wicketFielderId || undefined,
      },
    });
    onUpdateMatch(updated);
    setWicketModalOpen(false);
    setWicketFielderId('');
    setWicketRunsOnBall(0);
  };

  const handleSetOpening = (e: React.FormEvent) => {
    e.preventDefault();
    if (!openStriker || !openNonStriker || openStriker === openNonStriker || !openBowler) return;
    const nextMatch: Match = JSON.parse(JSON.stringify(match));
    const target = nextMatch.innings[innIdx];
    target.strikerId = openStriker;
    target.nonStrikerId = openNonStriker;
    target.currentBowlerId = openBowler;
    target.needsNewBatter = false;
    target.needsNewBowler = false;
    nextMatch.updatedAt = Date.now();
    onUpdateMatch(nextMatch);
  };

  const handleSelectNewBatter = (batterId: string) => {
    const nextMatch: Match = JSON.parse(JSON.stringify(match));
    const target = nextMatch.innings[innIdx];
    if (!target.strikerId) target.strikerId = batterId;
    else if (!target.nonStrikerId) target.nonStrikerId = batterId;
    target.needsNewBatter = false;
    nextMatch.updatedAt = Date.now();
    onUpdateMatch(nextMatch);
  };

  const handleSelectBowler = (bowlerId: string) => {
    const nextMatch: Match = JSON.parse(JSON.stringify(match));
    const target = nextMatch.innings[innIdx];
    target.currentBowlerId = bowlerId;
    target.needsNewBowler = false;
    nextMatch.updatedAt = Date.now();
    onUpdateMatch(nextMatch);
    setManualBowlerOpen(false);
  };

  const handleSwapStrike = () => {
    if (!inn.strikerId || !inn.nonStrikerId) return;
    const nextMatch: Match = JSON.parse(JSON.stringify(match));
    const target = nextMatch.innings[innIdx];
    const tmp = target.strikerId;
    target.strikerId = target.nonStrikerId;
    target.nonStrikerId = tmp;
    nextMatch.updatedAt = Date.now();
    onUpdateMatch(nextMatch);
  };

  const handleUndo = () => {
    if (inn.balls.length === 0) return;
    onUpdateMatch(undoLastBallInMatch(match));
  };

  const handleSetTestSession = (session: TestSessionName, advanceDay = false) => {
    if (!match.testState) return;
    const nextMatch: Match = JSON.parse(JSON.stringify(match));
    if (nextMatch.testState) {
      nextMatch.testState.session = session;
      if (advanceDay && nextMatch.testState.day < 5) {
        nextMatch.testState.day = (nextMatch.testState.day + 1) as 1 | 2 | 3 | 4 | 5;
      }
    }
    nextMatch.updatedAt = Date.now();
    onUpdateMatch(nextMatch);
  };

  const handleFollowOnChoice = (enforce: boolean) => {
    const nextMatch: Match = JSON.parse(JSON.stringify(match));
    if (nextMatch.testState) {
      nextMatch.testState.followOnEnforced = enforce;
      nextMatch.testState.followOnResolved = true;
    }
    const nextBattingSide = enforce ? inn.battingTeamSide : inn.bowlingTeamSide;
    onUpdateMatch(startNextInnings(nextMatch, nextBattingSide));
  };

  const handleShare = async () => {
    const text = generateShareableScorecard(match);
    try {
      if (navigator.share) {
        await navigator.share({ title: match.title, text });
        setShareFeedback('Shared');
      } else {
        await navigator.clipboard.writeText(text);
        setShareFeedback('Copied to clipboard');
      }
    } catch {
      try {
        await navigator.clipboard.writeText(text);
        setShareFeedback('Copied to clipboard');
      } catch {
        setShareFeedback('Share cancelled');
      }
    }
    window.setTimeout(() => setShareFeedback(''), 2500);
  };

  const openBallEditor = (ball: BallEvent) => {
    setEditingBall(ball);
    setEditRunsOffBat(ball.runsOffBat);
    setEditExtraType(ball.extraType);
    setEditExtraRuns(ball.extraRuns);
    setEditModalOpen(true);
  };

  const saveBallEdit = () => {
    if (!editingBall) return;
    const updated = editBallInMatch(match, innIdx, editingBall.id, {
      runsOffBat: editRunsOffBat,
      extraType: editExtraType,
      extraRuns: editExtraRuns,
    });
    onUpdateMatch(updated);
    setEditingBall(null);
    setEditModalOpen(false);
  };

  return (
    <div className="space-y-4 pb-6">
      {/* Compact Top Bar */}
      <div className="flex items-center justify-between gap-3 border-b border-white/15 pb-3">
        <div className="flex items-center gap-2.5 min-w-0">
          <button
            type="button"
            onClick={onExit}
            className="min-h-[44px] min-w-[44px] rounded-xl border border-white/15 flex items-center justify-center text-white hover:bg-white/10 shrink-0"
            aria-label="Back to Home"
          >
            <ArrowLeft className="w-5 h-5" />
          </button>
          <div className="min-w-0">
            <div className="text-xs font-mono text-neutral-400 truncate">
              {getFormatDefaults(match.format).label}
              {match.testState ? ` · Day ${match.testState.day} (${match.testState.session})` : ''}
            </div>
            <h1 className="text-sm sm:text-base font-semibold text-white truncate">
              {match.title}
            </h1>
          </div>
        </div>
        <div className="flex items-center gap-2 shrink-0">
          <button
            type="button"
            onClick={onOpenScorecard}
            className="min-h-[44px] px-3.5 rounded-xl border border-white/20 text-white text-xs font-medium hover:bg-white/10 inline-flex items-center gap-1.5 whitespace-nowrap"
          >
            <ClipboardList className="w-4 h-4" />
            <span>Scorecard</span>
          </button>
        </div>
      </div>

      {/* Main Scoreboard + Scoring Pad Grid (Responsive 1 col mobile / 2 col desktop) */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-5 items-start">
        {/* Left / Top: Live Scoreboard & Crease Info */}
        <div className="lg:col-span-7 space-y-4">
          {/* Scoreboard Card */}
          <div className="rounded-2xl bg-neutral-950 border border-white/20 p-5 space-y-3">
            <div className="flex items-start justify-between gap-4">
              <div>
                <div className="text-xs font-mono text-neutral-400">
                  {inn.inningsNumber === 1
                    ? '1ST INNINGS'
                    : inn.inningsNumber === 2
                    ? '2ND INNINGS'
                    : inn.inningsNumber === 3
                    ? '3RD INNINGS'
                    : '4TH INNINGS'}
                </div>
                <div className="text-xl sm:text-2xl font-bold text-white mt-0.5">
                  {battingTeam.name}
                </div>
              </div>
              <div className="text-right">
                <div className="font-mono text-4xl sm:text-5xl font-bold tabular-nums text-white leading-none">
                  {stats.totalRuns}/{stats.wickets}
                </div>
                <div className="font-mono text-sm tabular-nums text-neutral-300 mt-1.5">
                  {stats.oversDisplay}
                  {match.oversPerInnings !== null ? ` / ${match.oversPerInnings}` : ''} ov
                </div>
              </div>
            </div>

            {/* Metrics Row */}
            <div className="pt-3 border-t border-white/10 flex flex-wrap items-center justify-between gap-x-4 gap-y-1.5 text-xs font-mono tabular-nums text-neutral-300">
              <div className="flex flex-wrap items-center gap-3">
                <span>CRR {stats.runRate.toFixed(2)}</span>
                {overview.target !== null && (
                  <>
                    <span aria-hidden="true">·</span>
                    <span>Target {overview.target}</span>
                  </>
                )}
                {overview.requiredRunRate !== null && (
                  <>
                    <span aria-hidden="true">·</span>
                    <span>RRR {overview.requiredRunRate.toFixed(2)}</span>
                  </>
                )}
              </div>
              <span>Extras {stats.extras.total}</span>
            </div>

            <div className="text-xs sm:text-sm font-medium text-white bg-black border border-white/10 rounded-xl px-3.5 py-2.5">
              {overview.statusLine}
            </div>

            {/* Previous Innings Strip for Multi-Innings Context */}
            {match.innings.length > 1 && (
              <div className="flex flex-wrap gap-x-4 gap-y-1 text-xs font-mono text-neutral-400 pt-1">
                {match.innings.slice(0, -1).map((prevInn, i) => {
                  const pt = getTeamSnapshot(match, prevInn.battingTeamSide);
                  const ps = overview.inningsStats[i];
                  return (
                    <span key={prevInn.inningsNumber}>
                      {pt.shortName} ({prevInn.inningsNumber}i): {ps.totalRuns}/{ps.wickets}
                      {prevInn.isDeclared ? 'd' : ''} ({ps.oversDisplay})
                    </span>
                  );
                })}
              </div>
            )}
          </div>

          {/* Batters & Bowler Table */}
          <div className="rounded-2xl bg-neutral-950 border border-white/15 p-4 space-y-4">
            {/* Batters */}
            <div className="space-y-2">
              <div className="flex items-center justify-between text-xs text-neutral-400 font-mono pb-1 border-b border-white/10">
                <span>BATTERS</span>
                <div className="flex items-center gap-4 tabular-nums">
                  <span className="w-8 text-right">R</span>
                  <span className="w-8 text-right">B</span>
                  <span className="w-7 text-right">4s</span>
                  <span className="w-7 text-right">6s</span>
                  <span className="w-11 text-right">SR</span>
                </div>
              </div>

              {[
                { id: inn.strikerId, stat: strikerStats, onStrike: true },
                { id: inn.nonStrikerId, stat: nonStrikerStats, onStrike: false },
              ].map((row, i) => {
                const name = row.id ? getPlayerName(battingTeam, row.id) : 'Select Batter';
                const r = row.stat;
                return (
                  <div
                    key={row.id || `slot_${i}`}
                    className="flex items-center justify-between text-sm py-1"
                  >
                    <div className="flex items-center gap-1.5 min-w-0 pr-2">
                      <span className="font-semibold text-white truncate">
                        {name}
                        {row.onStrike && row.id ? ' *' : ''}
                      </span>
                    </div>
                    <div className="flex items-center gap-4 font-mono text-xs tabular-nums text-neutral-200 shrink-0">
                      <span className="w-8 text-right font-bold text-white">{r?.runs ?? 0}</span>
                      <span className="w-8 text-right text-neutral-400">{r?.balls ?? 0}</span>
                      <span className="w-7 text-right text-neutral-400">{r?.fours ?? 0}</span>
                      <span className="w-7 text-right text-neutral-400">{r?.sixes ?? 0}</span>
                      <span className="w-11 text-right text-neutral-400">
                        {r ? r.strikeRate.toFixed(1) : '0.0'}
                      </span>
                    </div>
                  </div>
                );
              })}
            </div>

            {/* Bowler */}
            <div className="pt-3 border-t border-white/10 space-y-2">
              <div className="flex items-center justify-between text-xs text-neutral-400 font-mono">
                <button
                  type="button"
                  onClick={() => setManualBowlerOpen(true)}
                  className="text-white hover:underline text-left"
                >
                  BOWLER (Tap to change)
                </button>
                <div className="flex items-center gap-4 tabular-nums">
                  <span className="w-8 text-right">O</span>
                  <span className="w-6 text-right">M</span>
                  <span className="w-8 text-right">R</span>
                  <span className="w-6 text-right">W</span>
                  <span className="w-11 text-right">ECO</span>
                </div>
              </div>
              <div className="flex items-center justify-between text-sm py-1">
                <span className="font-semibold text-white truncate pr-2">
                  {inn.currentBowlerId
                    ? getPlayerName(bowlingTeam, inn.currentBowlerId)
                    : 'Select Bowler'}
                </span>
                <div className="flex items-center gap-4 font-mono text-xs tabular-nums text-neutral-200 shrink-0">
                  <span className="w-8 text-right">{currentBowlerStats?.oversDisplay ?? '0.0'}</span>
                  <span className="w-6 text-right text-neutral-400">
                    {currentBowlerStats?.maidens ?? 0}
                  </span>
                  <span className="w-8 text-right">{currentBowlerStats?.runs ?? 0}</span>
                  <span className="w-6 text-right font-bold text-white">
                    {currentBowlerStats?.wickets ?? 0}
                  </span>
                  <span className="w-11 text-right text-neutral-400">
                    {currentBowlerStats ? currentBowlerStats.economy.toFixed(2) : '0.00'}
                  </span>
                </div>
              </div>
            </div>

            {/* This Over Strip */}
            <div className="pt-3 border-t border-white/10 flex items-center justify-between gap-3">
              <span className="text-xs font-mono text-neutral-400 shrink-0">THIS OVER</span>
              <div className="flex flex-wrap items-center gap-1.5 justify-end">
                {stats.currentOverBalls.length === 0 ? (
                  <span className="text-xs text-neutral-500">New over</span>
                ) : (
                  stats.currentOverBalls.map((b) => {
                    const label = formatBallBadge(b);
                    const isHighlight = b.wicket || b.runsOffBat === 4 || b.runsOffBat === 6;
                    return (
                      <button
                        key={b.id}
                        type="button"
                        onClick={() => openBallEditor(b)}
                        title="Tap to edit ball"
                        className={`min-w-[32px] h-8 px-2 rounded-lg font-mono text-xs font-semibold tabular-nums border transition ${
                          isHighlight
                            ? 'bg-white text-black border-white'
                            : 'bg-black text-white border-white/25 hover:border-white'
                        }`}
                      >
                        {label}
                      </button>
                    );
                  })
                )}
              </div>
            </div>
          </div>

          {/* Test Match Session Controls */}
          {match.format === 'TEST' && match.status === 'in_progress' && match.testState && (
            <div className="rounded-2xl bg-neutral-950 border border-white/15 p-4 space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-xs font-mono text-neutral-400">
                  TEST CONTROLS · DAY {match.testState.day}/5
                </span>
                <span className="text-xs font-mono text-white">
                  {match.testState.session}
                </span>
              </div>
              <div className="flex flex-wrap gap-2">
                {(['Morning', 'Lunch', 'Afternoon', 'Tea', 'Evening'] as TestSessionName[]).map(
                  (sess) => (
                    <button
                      key={sess}
                      type="button"
                      onClick={() => handleSetTestSession(sess)}
                      className={`min-h-[38px] px-3 rounded-lg text-xs border transition ${
                        match.testState?.session === sess
                          ? 'bg-white text-black border-white font-semibold'
                          : 'bg-black text-neutral-300 border-white/15 hover:border-white/40'
                      }`}
                    >
                      {sess}
                    </button>
                  )
                )}
                <button
                  type="button"
                  onClick={() => handleSetTestSession('Stumps', true)}
                  className="min-h-[38px] px-3 rounded-lg text-xs border border-white/20 bg-black text-white hover:bg-white/10"
                >
                  Stumps (Next Day)
                </button>
              </div>
            </div>
          )}
        </div>

        {/* Right / Bottom: Thumb-Zone Scoring Keypad */}
        <div className="lg:col-span-5 space-y-3">
          {match.status === 'completed' && match.result ? (
            <div className="rounded-2xl bg-neutral-950 border border-white p-6 space-y-5">
              <div className="space-y-1.5">
                <p className="text-xs font-mono text-neutral-400">MATCH COMPLETED</p>
                <h2 className="font-display text-3xl font-bold text-white">
                  {match.result.summary}
                </h2>
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <button
                  type="button"
                  onClick={onOpenScorecard}
                  className="min-h-[48px] px-4 rounded-xl bg-white text-black text-sm font-semibold hover:bg-neutral-200"
                >
                  Full Scorecard
                </button>
                <button
                  type="button"
                  onClick={handleShare}
                  className="min-h-[48px] px-4 rounded-xl border border-white/25 text-white text-sm font-medium hover:bg-white/10 inline-flex items-center justify-center gap-2"
                >
                  <Share2 className="w-4 h-4" />
                  <span>{shareFeedback || 'Share Result'}</span>
                </button>
              </div>
              {inn.balls.length > 0 && (
                <button
                  type="button"
                  onClick={handleUndo}
                  className="w-full min-h-[44px] rounded-xl border border-white/15 text-xs text-neutral-300 hover:text-white inline-flex items-center justify-center gap-2"
                >
                  <RotateCcw className="w-3.5 h-3.5" />
                  <span>Undo Last Ball</span>
                </button>
              )}
            </div>
          ) : (
            <div className="rounded-2xl bg-neutral-950 border border-white/20 p-4 space-y-3">
              {/* Primary Run Buttons (White with Black Text) */}
              <div className="grid grid-cols-4 gap-2.5">
                {[0, 1, 2, 3, 4, 5, 6].map((run) => (
                  <button
                    key={run}
                    type="button"
                    onClick={() => handleScoreRun(run)}
                    className="min-h-[58px] rounded-xl bg-white text-black font-mono text-2xl font-bold hover:bg-neutral-200 active:scale-[0.96] transition"
                  >
                    {run}
                  </button>
                ))}
                <button
                  type="button"
                  onClick={() => {
                    setWicketDismissedId(inn.strikerId || '');
                    setWicketKind('caught');
                    setWicketModalOpen(true);
                  }}
                  className="min-h-[58px] rounded-xl bg-black border-2 border-white text-white font-display text-xl font-bold tracking-wide hover:bg-white hover:text-black active:scale-[0.96] transition"
                >
                  OUT
                </button>
              </div>

              {/* Extras Row */}
              <div className="grid grid-cols-4 gap-2">
                {(
                  [
                    { key: 'wide', label: 'Wide' },
                    { key: 'noball', label: 'No Ball' },
                    { key: 'bye', label: 'Bye' },
                    { key: 'legbye', label: 'Leg Bye' },
                  ] as const
                ).map((ex) => (
                  <button
                    key={ex.key}
                    type="button"
                    onClick={() => setExtraSheet(extraSheet === ex.key ? null : ex.key)}
                    className={`min-h-[48px] rounded-xl text-xs font-semibold border transition ${
                      extraSheet === ex.key
                        ? 'bg-white text-black border-white'
                        : 'bg-black text-white border-white/20 hover:border-white/50'
                    }`}
                  >
                    {ex.label}
                  </button>
                ))}
              </div>

              {/* Inline Extra Sub-Selector */}
              {extraSheet === 'wide' && (
                <div className="rounded-xl bg-black border border-white/25 p-3 space-y-2">
                  <div className="flex items-center justify-between text-xs text-neutral-400">
                    <span>Select Wide Runs (includes 1 penalty)</span>
                    <button type="button" onClick={() => setExtraSheet(null)} className="text-white">
                      Close
                    </button>
                  </div>
                  <div className="grid grid-cols-5 gap-2">
                    {[1, 2, 3, 4, 5].map((total) => (
                      <button
                        key={total}
                        type="button"
                        onClick={() => handleScoreExtra('wide', total, 0)}
                        className="min-h-[44px] rounded-lg bg-white text-black font-mono text-xs font-bold hover:bg-neutral-200"
                      >
                        {total === 1 ? 'WD' : `WD+${total - 1}`}
                      </button>
                    ))}
                  </div>
                </div>
              )}

              {extraSheet === 'noball' && (
                <div className="rounded-xl bg-black border border-white/25 p-3 space-y-2">
                  <div className="flex items-center justify-between text-xs text-neutral-400">
                    <span>No Ball (+ runs off bat)</span>
                    <button type="button" onClick={() => setExtraSheet(null)} className="text-white">
                      Close
                    </button>
                  </div>
                  <div className="grid grid-cols-4 gap-2">
                    {[0, 1, 2, 3, 4, 6].map((bat) => (
                      <button
                        key={bat}
                        type="button"
                        onClick={() => handleScoreExtra('noball', 1, bat)}
                        className="min-h-[44px] rounded-lg bg-white text-black font-mono text-xs font-bold hover:bg-neutral-200"
                      >
                        {bat === 0 ? 'NB' : `NB+${bat}`}
                      </button>
                    ))}
                    <button
                      type="button"
                      onClick={() => handleScoreExtra('noball', 2, 0)}
                      className="min-h-[44px] rounded-lg border border-white/30 text-white font-mono text-xs font-semibold hover:bg-white/10 col-span-2"
                    >
                      NB + 1 Bye
                    </button>
                  </div>
                </div>
              )}

              {(extraSheet === 'bye' || extraSheet === 'legbye') && (
                <div className="rounded-xl bg-black border border-white/25 p-3 space-y-2">
                  <div className="flex items-center justify-between text-xs text-neutral-400">
                    <span>{extraSheet === 'bye' ? 'Byes' : 'Leg Byes'} Runs</span>
                    <button type="button" onClick={() => setExtraSheet(null)} className="text-white">
                      Close
                    </button>
                  </div>
                  <div className="grid grid-cols-5 gap-2">
                    {[1, 2, 3, 4, 5].map((r) => (
                      <button
                        key={r}
                        type="button"
                        onClick={() => handleScoreExtra(extraSheet, r, 0)}
                        className="min-h-[44px] rounded-lg bg-white text-black font-mono text-xs font-bold hover:bg-neutral-200"
                      >
                        {extraSheet === 'bye' ? `B${r}` : `LB${r}`}
                      </button>
                    ))}
                  </div>
                </div>
              )}

              {/* Utility Controls Row */}
              <div className="grid grid-cols-3 gap-2 pt-1">
                <button
                  type="button"
                  onClick={handleUndo}
                  disabled={inn.balls.length === 0}
                  className="min-h-[46px] rounded-xl border border-white/20 text-white text-xs font-medium hover:bg-white/10 disabled:opacity-35 inline-flex items-center justify-center gap-1.5"
                >
                  <RotateCcw className="w-3.5 h-3.5" />
                  <span>Undo</span>
                </button>
                <button
                  type="button"
                  onClick={handleSwapStrike}
                  className="min-h-[46px] rounded-xl border border-white/20 text-white text-xs font-medium hover:bg-white/10 inline-flex items-center justify-center gap-1.5"
                >
                  <ArrowLeftRight className="w-3.5 h-3.5" />
                  <span>Swap</span>
                </button>
                <button
                  type="button"
                  onClick={() => {
                    const last = inn.balls[inn.balls.length - 1];
                    if (last) openBallEditor(last);
                  }}
                  disabled={inn.balls.length === 0}
                  className="min-h-[46px] rounded-xl border border-white/20 text-white text-xs font-medium hover:bg-white/10 disabled:opacity-35 inline-flex items-center justify-center gap-1.5"
                >
                  <Edit3 className="w-3.5 h-3.5" />
                  <span>Edit Last</span>
                </button>
              </div>

              {/* Innings Closure / Declaration Controls */}
              <div className="flex flex-wrap gap-2 pt-2 border-t border-white/10">
                <button
                  type="button"
                  onClick={() => setConfirmAction('declare')}
                  className="flex-1 min-h-[44px] px-3 rounded-xl border border-white/20 text-xs text-neutral-300 hover:text-white hover:border-white/40"
                >
                  {match.format === 'TEST' ? 'Declare Innings' : 'End Innings'}
                </button>
                {match.format === 'TEST' && (
                  <button
                    type="button"
                    onClick={() => setConfirmAction('draw')}
                    className="min-h-[44px] px-4 rounded-xl border border-white/20 text-xs text-neutral-300 hover:text-white hover:border-white/40"
                  >
                    Match Draw
                  </button>
                )}
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Modal: Opening Players Selection */}
      {needsOpening && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/85 p-4">
          <form
            onSubmit={handleSetOpening}
            className="w-full max-w-md rounded-2xl bg-neutral-950 border border-white/25 p-6 space-y-4"
          >
            <h2 className="text-xl font-bold text-white">
              Select Openers ({battingTeam.shortName})
            </h2>
            <div>
              <label className="block text-xs text-neutral-400 mb-1">Striker</label>
              <select
                value={openStriker}
                onChange={(e) => setOpenStriker(e.target.value)}
                className="w-full min-h-[44px] px-3 rounded-xl bg-black border border-white/20 text-white text-sm"
              >
                {battingPool.map((p) => (
                  <option key={p.id} value={p.id}>
                    {p.name}
                  </option>
                ))}
              </select>
            </div>
            <div>
              <label className="block text-xs text-neutral-400 mb-1">Non-Striker</label>
              <select
                value={openNonStriker}
                onChange={(e) => setOpenNonStriker(e.target.value)}
                className="w-full min-h-[44px] px-3 rounded-xl bg-black border border-white/20 text-white text-sm"
              >
                {battingPool
                  .filter((p) => p.id !== openStriker)
                  .map((p) => (
                    <option key={p.id} value={p.id}>
                      {p.name}
                    </option>
                  ))}
              </select>
            </div>
            <div>
              <label className="block text-xs text-neutral-400 mb-1">
                Opening Bowler ({bowlingTeam.shortName})
              </label>
              <select
                value={openBowler}
                onChange={(e) => setOpenBowler(e.target.value)}
                className="w-full min-h-[44px] px-3 rounded-xl bg-black border border-white/20 text-white text-sm"
              >
                {bowlingPool.map((p) => (
                  <option key={p.id} value={p.id}>
                    {p.name}
                  </option>
                ))}
              </select>
            </div>
            <button
              type="submit"
              className="w-full min-h-[48px] rounded-xl bg-white text-black text-sm font-bold hover:bg-neutral-200"
            >
              Start Innings
            </button>
          </form>
        </div>
      )}

      {/* Modal: Wicket Entry */}
      {wicketModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/85 p-4">
          <div className="w-full max-w-md rounded-2xl bg-neutral-950 border border-white/25 p-6 space-y-4 max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between">
              <h2 className="text-lg font-bold text-white">Record Wicket</h2>
              <button
                type="button"
                onClick={() => setWicketModalOpen(false)}
                className="min-h-[40px] min-w-[40px] flex items-center justify-center text-neutral-400 hover:text-white"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="grid grid-cols-2 gap-2">
              {(
                [
                  { id: 'caught', label: 'Caught' },
                  { id: 'bowled', label: 'Bowled' },
                  { id: 'lbw', label: 'LBW' },
                  { id: 'runout', label: 'Run Out' },
                  { id: 'stumped', label: 'Stumped' },
                  { id: 'hitwicket', label: 'Hit Wicket' },
                  { id: 'retiredhurt', label: 'Retired Hurt' },
                ] as const
              ).map((k) => (
                <button
                  key={k.id}
                  type="button"
                  onClick={() => setWicketKind(k.id)}
                  className={`min-h-[44px] px-3 rounded-xl text-xs font-semibold border transition ${
                    wicketKind === k.id
                      ? 'bg-white text-black border-white'
                      : 'bg-black text-neutral-300 border-white/15'
                  }`}
                >
                  {k.label}
                </button>
              ))}
            </div>

            {(wicketKind === 'runout' || wicketKind === 'retiredhurt') && (
              <div>
                <label className="block text-xs text-neutral-400 mb-1.5">
                  Dismissed / Retired Batter
                </label>
                <div className="grid grid-cols-2 gap-2">
                  {[inn.strikerId, inn.nonStrikerId].filter(Boolean).map((bid) => (
                    <button
                      key={bid}
                      type="button"
                      onClick={() => setWicketDismissedId(bid!)}
                      className={`min-h-[42px] px-3 rounded-xl text-xs border truncate ${
                        wicketDismissedId === bid
                          ? 'bg-white text-black border-white font-semibold'
                          : 'bg-black text-white border-white/15'
                      }`}
                    >
                      {getPlayerName(battingTeam, bid)}
                    </button>
                  ))}
                </div>
              </div>
            )}

            {wicketKind === 'runout' && (
              <div>
                <label className="block text-xs text-neutral-400 mb-1.5">
                  Runs Completed Before Run Out
                </label>
                <div className="grid grid-cols-4 gap-2">
                  {[0, 1, 2, 3].map((r) => (
                    <button
                      key={r}
                      type="button"
                      onClick={() => setWicketRunsOnBall(r)}
                      className={`min-h-[42px] rounded-xl font-mono text-sm border ${
                        wicketRunsOnBall === r
                          ? 'bg-white text-black border-white font-bold'
                          : 'bg-black text-white border-white/15'
                      }`}
                    >
                      {r}
                    </button>
                  ))}
                </div>
              </div>
            )}

            {(wicketKind === 'caught' || wicketKind === 'runout' || wicketKind === 'stumped') && (
              <div>
                <label className="block text-xs text-neutral-400 mb-1.5">
                  {wicketKind === 'stumped' ? 'Wicketkeeper' : 'Fielder'}
                </label>
                <select
                  value={wicketFielderId}
                  onChange={(e) => setWicketFielderId(e.target.value)}
                  className="w-full min-h-[44px] px-3 rounded-xl bg-black border border-white/20 text-white text-sm"
                >
                  <option value="">Select Fielder (Optional)</option>
                  {bowlingPool.map((p) => (
                    <option key={p.id} value={p.id}>
                      {p.name}
                    </option>
                  ))}
                </select>
              </div>
            )}

            <button
              type="button"
              onClick={handleConfirmWicket}
              className="w-full min-h-[48px] rounded-xl bg-white text-black text-sm font-bold hover:bg-neutral-200"
            >
              Confirm {wicketKind === 'retiredhurt' ? 'Retired Hurt' : 'Wicket'}
            </button>
          </div>
        </div>
      )}

      {/* Modal: Select New Batter */}
      {needsNewBatter && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/85 p-4">
          <div className="w-full max-w-md rounded-2xl bg-neutral-950 border border-white/25 p-6 space-y-4">
            <h2 className="text-lg font-bold text-white">Select Next Batter</h2>
            <div className="space-y-2 max-h-72 overflow-y-auto pr-1">
              {availableBatters.map((p) => (
                <button
                  key={p.id}
                  type="button"
                  onClick={() => handleSelectNewBatter(p.id)}
                  className="w-full min-h-[46px] px-4 rounded-xl bg-black border border-white/20 hover:bg-white hover:text-black text-left text-sm font-medium text-white transition flex items-center justify-between"
                >
                  <span>{p.name}</span>
                  <span className="text-xs font-mono opacity-70">{p.role}</span>
                </button>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* Modal: Select Next Bowler */}
      {(needsNewBowler || manualBowlerOpen) && !inn.isCompleted && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/85 p-4">
          <div className="w-full max-w-md rounded-2xl bg-neutral-950 border border-white/25 p-6 space-y-4">
            <div className="flex items-center justify-between">
              <h2 className="text-lg font-bold text-white">
                {needsNewBowler ? 'End of Over — Next Bowler' : 'Change Bowler'}
              </h2>
              {manualBowlerOpen && !needsNewBowler && (
                <button
                  type="button"
                  onClick={() => setManualBowlerOpen(false)}
                  className="min-h-[40px] min-w-[40px] flex items-center justify-center text-neutral-400 hover:text-white"
                >
                  <X className="w-5 h-5" />
                </button>
              )}
            </div>
            <div className="space-y-2 max-h-72 overflow-y-auto pr-1">
              {(availableBowlers.length > 0 ? availableBowlers : bowlingPool).map((p) => {
                const bw = stats.bowlers.find((b) => b.playerId === p.id);
                return (
                  <button
                    key={p.id}
                    type="button"
                    onClick={() => handleSelectBowler(p.id)}
                    className="w-full min-h-[46px] px-4 rounded-xl bg-black border border-white/20 hover:bg-white hover:text-black text-left text-sm font-medium text-white transition flex items-center justify-between"
                  >
                    <span>{p.name}</span>
                    <span className="text-xs font-mono opacity-70 tabular-nums">
                      {bw ? `${bw.oversDisplay}-${bw.runs}-${bw.wickets}` : '0.0-0-0'}
                    </span>
                  </button>
                );
              })}
            </div>
          </div>
        </div>
      )}

      {/* Modal: Follow-On Decision or Innings Break */}
      {inn.isCompleted && match.status === 'in_progress' && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/85 p-4">
          <div className="w-full max-w-md rounded-2xl bg-neutral-950 border border-white p-6 space-y-5">
            {overview.isFollowOnEligible ? (
              <>
                <div className="space-y-1">
                  <p className="text-xs font-mono text-neutral-400">FOLLOW-ON RULE</p>
                  <h2 className="text-xl font-bold text-white">Follow-On Available</h2>
                  <p className="text-sm text-neutral-300 pt-1">
                    {bowlingTeam.name} lead by {overview.teamATotalRuns !== overview.teamBTotalRuns ? Math.abs(overview.teamATotalRuns - overview.teamBTotalRuns) : 0} runs (threshold: {match.followOnThreshold}). Enforce the follow-on?
                  </p>
                </div>
                <div className="grid grid-cols-1 gap-2.5">
                  <button
                    type="button"
                    onClick={() => handleFollowOnChoice(true)}
                    className="min-h-[48px] rounded-xl bg-white text-black text-sm font-bold hover:bg-neutral-200"
                  >
                    Enforce Follow-On ({battingTeam.shortName} bat again)
                  </button>
                  <button
                    type="button"
                    onClick={() => handleFollowOnChoice(false)}
                    className="min-h-[48px] rounded-xl border border-white/25 text-white text-sm font-medium hover:bg-white/10"
                  >
                    Bat Normally ({bowlingTeam.shortName} bat 3rd)
                  </button>
                </div>
              </>
            ) : (
              <>
                <div className="space-y-1">
                  <p className="text-xs font-mono text-neutral-400">INNINGS COMPLETED</p>
                  <h2 className="text-2xl font-bold text-white">
                    {battingTeam.name}: {stats.totalRuns}/{stats.wickets} ({stats.oversDisplay})
                  </h2>
                  <p className="text-sm text-neutral-300 pt-1">{overview.statusLine}</p>
                </div>
                <div className="space-y-2.5">
                  <button
                    type="button"
                    onClick={() => onUpdateMatch(startNextInnings(match, inn.bowlingTeamSide))}
                    className="w-full min-h-[48px] rounded-xl bg-white text-black text-sm font-bold hover:bg-neutral-200"
                  >
                    Start Innings {match.innings.length + 1} ({bowlingTeam.shortName} Batting)
                  </button>
                  <button
                    type="button"
                    onClick={handleUndo}
                    className="w-full min-h-[44px] rounded-xl border border-white/20 text-neutral-300 text-xs hover:text-white"
                  >
                    Undo Last Ball
                  </button>
                </div>
              </>
            )}
          </div>
        </div>
      )}

      {/* Modal: Edit Previous Ball */}
      {editModalOpen && editingBall && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/85 p-4">
          <div className="w-full max-w-sm rounded-2xl bg-neutral-950 border border-white/25 p-6 space-y-4">
            <div className="flex items-center justify-between">
              <h2 className="text-base font-bold text-white">
                Edit Ball {editingBall.overNumber}.{editingBall.ballInOver}
              </h2>
              <button
                type="button"
                onClick={() => setEditModalOpen(false)}
                className="min-h-[36px] min-w-[36px] flex items-center justify-center text-neutral-400 hover:text-white"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div>
              <label className="block text-xs text-neutral-400 mb-1.5">Extra Type</label>
              <div className="grid grid-cols-3 gap-1.5">
                {(['none', 'wide', 'noball', 'bye', 'legbye'] as ExtraType[]).map((et) => (
                  <button
                    key={et}
                    type="button"
                    onClick={() => {
                      setEditExtraType(et);
                      if (et === 'none') setEditExtraRuns(0);
                      else if ((et === 'wide' || et === 'noball') && editExtraRuns === 0)
                        setEditExtraRuns(1);
                    }}
                    className={`min-h-[38px] rounded-lg text-xs border capitalize ${
                      editExtraType === et
                        ? 'bg-white text-black border-white font-semibold'
                        : 'bg-black text-neutral-300 border-white/15'
                    }`}
                  >
                    {et}
                  </button>
                ))}
              </div>
            </div>

            <div>
              <label className="block text-xs text-neutral-400 mb-1.5">Runs Off Bat</label>
              <div className="grid grid-cols-7 gap-1.5">
                {[0, 1, 2, 3, 4, 5, 6].map((r) => (
                  <button
                    key={r}
                    type="button"
                    onClick={() => setEditRunsOffBat(r)}
                    className={`min-h-[40px] rounded-lg font-mono text-xs border ${
                      editRunsOffBat === r
                        ? 'bg-white text-black border-white font-bold'
                        : 'bg-black text-white border-white/15'
                    }`}
                  >
                    {r}
                  </button>
                ))}
              </div>
            </div>

            {editExtraType !== 'none' && (
              <div>
                <label className="block text-xs text-neutral-400 mb-1.5">
                  Extra Runs (incl. penalty)
                </label>
                <input
                  type="number"
                  min={1}
                  max={10}
                  value={editExtraRuns}
                  onChange={(e) => setEditExtraRuns(Math.max(1, Number(e.target.value)))}
                  className="w-full min-h-[42px] px-3 rounded-xl bg-black border border-white/20 text-white font-mono text-sm"
                />
              </div>
            )}

            <div className="flex justify-end gap-2 pt-2">
              <button
                type="button"
                onClick={() => setEditModalOpen(false)}
                className="min-h-[44px] px-4 rounded-xl border border-white/20 text-white text-xs"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={saveBallEdit}
                className="min-h-[44px] px-5 rounded-xl bg-white text-black text-xs font-bold inline-flex items-center gap-1.5"
              >
                <Check className="w-4 h-4" />
                <span>Update Score</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Modal: Confirm Declare or Draw */}
      {confirmAction && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/85 p-4">
          <div className="w-full max-w-sm rounded-2xl bg-neutral-950 border border-white/25 p-6 space-y-4">
            <h2 className="text-lg font-bold text-white">
              {confirmAction === 'declare'
                ? match.format === 'TEST'
                  ? 'Declare Current Innings?'
                  : 'End Current Innings?'
                : 'End Test Match as a Draw?'}
            </h2>
            <p className="text-sm text-neutral-400">
              {confirmAction === 'declare'
                ? 'This will close the current innings immediately.'
                : 'This will conclude the match and record the official result as Match Drawn.'}
            </p>
            <div className="flex justify-end gap-2">
              <button
                type="button"
                onClick={() => setConfirmAction(null)}
                className="min-h-[44px] px-4 rounded-xl border border-white/20 text-white text-xs"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={() => {
                  if (confirmAction === 'declare') {
                    onUpdateMatch(declareCurrentInnings(match));
                  } else {
                    onUpdateMatch(drawTestMatch(match));
                  }
                  setConfirmAction(null);
                }}
                className="min-h-[44px] px-5 rounded-xl bg-white text-black text-xs font-bold"
              >
                Confirm
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
