export type MatchFormat =
  | 'TEST'
  | 'ODI'
  | 'T20'
  | 'T10'
  | 'T5'
  | 'CUSTOM'
  | 'PRACTICE';

export type ExtraType = 'none' | 'wide' | 'noball' | 'bye' | 'legbye';

export type WicketKind =
  | 'bowled'
  | 'caught'
  | 'lbw'
  | 'runout'
  | 'stumped'
  | 'hitwicket'
  | 'retiredhurt';

export type PlayerRole = 'BAT' | 'BOWL' | 'AR' | 'WK';

export interface Player {
  id: string;
  name: string;
  role: PlayerRole;
}

export interface Team {
  id: string;
  name: string;
  shortName: string;
  players: Player[];
  defaultCaptainId?: string;
  defaultKeeperId?: string;
  defaultPlayingXI: string[];
  createdAt: number;
  updatedAt: number;
}

export interface MatchTeamSnapshot {
  teamId: string;
  name: string;
  shortName: string;
  players: Player[];
  playingXI: string[];
  substitutes: string[];
  captainId?: string;
  keeperId?: string;
}

export interface WicketInfo {
  kind: WicketKind;
  dismissedBatsmanId: string;
  fielderId?: string;
}

export interface BallEvent {
  id: string;
  overNumber: number; // 0-indexed over
  ballInOver: number; // 1-indexed legal ball in over (or current count for extras)
  strikerId: string;
  nonStrikerId: string;
  bowlerId: string;
  runsOffBat: number;
  extraType: ExtraType;
  extraRuns: number; // includes penalty (1 for WD/NB) + running extras
  isLegal: boolean;
  wicket?: WicketInfo;
  timestamp: number;
}

export interface InningsData {
  inningsNumber: 1 | 2 | 3 | 4;
  battingTeamSide: 'teamA' | 'teamB';
  bowlingTeamSide: 'teamA' | 'teamB';
  balls: BallEvent[];
  strikerId: string | null;
  nonStrikerId: string | null;
  currentBowlerId: string | null;
  previousBowlerId: string | null;
  isDeclared: boolean;
  isCompleted: boolean;
  closureReason?: 'all_out' | 'overs_completed' | 'target_achieved' | 'declared' | 'manual';
  needsNewBowler?: boolean;
  needsNewBatter?: boolean;
}

export type TestSessionName =
  | 'Morning'
  | 'Lunch'
  | 'Afternoon'
  | 'Tea'
  | 'Evening'
  | 'Stumps';

export interface TestSessionState {
  day: 1 | 2 | 3 | 4 | 5;
  session: TestSessionName;
  followOnOffered: boolean;
  followOnEnforced: boolean;
  followOnResolved: boolean;
}

export interface MatchResult {
  winnerSide: 'teamA' | 'teamB' | 'tie' | 'draw';
  summary: string;
  marginText: string;
}

export interface Match {
  id: string;
  title: string;
  format: MatchFormat;
  oversPerInnings: number | null; // null = unlimited (Test or unlimited Practice)
  maxBowlerOvers: number | null;
  playersPerSide: number;
  followOnThreshold: number; // default 200 for Test
  teams: {
    teamA: MatchTeamSnapshot;
    teamB: MatchTeamSnapshot;
  };
  toss: {
    winnerSide: 'teamA' | 'teamB';
    decision: 'bat' | 'bowl';
  };
  innings: InningsData[];
  currentInningsIndex: number;
  testState?: TestSessionState;
  status: 'in_progress' | 'completed';
  result?: MatchResult;
  tournamentId?: string;
  fixtureId?: string;
  createdAt: number;
  updatedAt: number;
}

export interface BatterStats {
  playerId: string;
  name: string;
  isCaptain: boolean;
  isKeeper: boolean;
  runs: number;
  balls: number;
  fours: number;
  sixes: number;
  strikeRate: number;
  batted: boolean;
  isOut: boolean;
  isRetiredHurt: boolean;
  dismissalText: string;
}

export interface BowlerStats {
  playerId: string;
  name: string;
  legalBalls: number;
  oversDisplay: string;
  maidens: number;
  runs: number;
  wickets: number;
  economy: number;
  wides: number;
  noballs: number;
}

export interface FallOfWicket {
  wicketNumber: number;
  runs: number;
  oversDisplay: string;
  playerId: string;
  playerName: string;
}

export interface Partnership {
  wicketIndex: number;
  batter1Id: string;
  batter1Name: string;
  batter2Id: string;
  batter2Name: string;
  runs: number;
  balls: number;
  isCurrent: boolean;
}

export interface InningsComputedStats {
  totalRuns: number;
  wickets: number;
  legalBalls: number;
  oversDisplay: string;
  runRate: number;
  extras: {
    total: number;
    byes: number;
    legByes: number;
    wides: number;
    noBalls: number;
  };
  batters: BatterStats[];
  bowlers: BowlerStats[];
  fallOfWickets: FallOfWicket[];
  partnerships: Partnership[];
  didNotBat: Player[];
  currentOverBalls: BallEvent[];
}

export interface TournamentFixture {
  id: string;
  round: number;
  label: string;
  teamAId: string;
  teamBId: string;
  matchId?: string;
  status: 'scheduled' | 'in_progress' | 'completed';
  resultSummary?: string;
  winnerTeamId?: string | 'tie' | 'draw';
}

export interface Tournament {
  id: string;
  name: string;
  format: 'ODI' | 'T20' | 'T10' | 'T5' | 'CUSTOM';
  oversPerInnings: number;
  playersPerSide: number;
  mode: 'round_robin' | 'knockout';
  teamIds: string[];
  fixtures: TournamentFixture[];
  createdAt: number;
  updatedAt: number;
}

export interface TournamentStandingRow {
  teamId: string;
  teamName: string;
  shortName: string;
  played: number;
  won: number;
  lost: number;
  tied: number;
  noResult: number;
  points: number;
  nrr: number;
}
