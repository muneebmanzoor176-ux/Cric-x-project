import { Match, Player, Team, Tournament } from '../types/cricket';
import { createId } from './cricketEngine';

const KEYS = {
  TEAMS: 'cricx_teams_v1',
  MATCHES: 'cricx_matches_v1',
  TOURNAMENTS: 'cricx_tournaments_v1',
  SEEDED: 'cricx_seeded_v1',
  CLEANED_BUILTIN: 'cricx_cleaned_builtin_v1',
} as const;

const LEGACY_BUILTIN_IDS = new Set(['team_black_xi', 'team_white_xi']);

function safeRead<T>(key: string, fallback: T): T {
  try {
    const raw = localStorage.getItem(key);
    if (!raw) return fallback;
    return JSON.parse(raw) as T;
  } catch {
    return fallback;
  }
}

function safeWrite<T>(key: string, value: T): void {
  try {
    localStorage.setItem(key, JSON.stringify(value));
  } catch {
    // Ignore quota errors cleanly
  }
}

export function loadTeams(): Team[] {
  const existing = safeRead<Team[]>(KEYS.TEAMS, []);
  if (!localStorage.getItem(KEYS.CLEANED_BUILTIN)) {
    const cleaned = existing.filter((t) => !LEGACY_BUILTIN_IDS.has(t.id));
    if (cleaned.length !== existing.length) {
      safeWrite(KEYS.TEAMS, cleaned);
    }
    localStorage.setItem(KEYS.CLEANED_BUILTIN, '1');
    return cleaned;
  }
  return existing;
}

export function saveTeams(teams: Team[]): void {
  safeWrite(KEYS.TEAMS, teams);
}

export function loadMatches(): Match[] {
  const list = safeRead<Match[]>(KEYS.MATCHES, []);
  return list.sort((a, b) => b.updatedAt - a.updatedAt);
}

export function saveMatches(matches: Match[]): void {
  safeWrite(KEYS.MATCHES, matches);
}

export function upsertMatch(match: Match): Match[] {
  const list = loadMatches();
  const idx = list.findIndex((m) => m.id === match.id);
  const updated = idx >= 0 ? list.map((m) => (m.id === match.id ? match : m)) : [match, ...list];
  saveMatches(updated);
  return updated.sort((a, b) => b.updatedAt - a.updatedAt);
}

export function deleteMatchById(matchId: string): Match[] {
  const list = loadMatches().filter((m) => m.id !== matchId);
  saveMatches(list);
  return list;
}

export function loadTournaments(): Tournament[] {
  const list = safeRead<Tournament[]>(KEYS.TOURNAMENTS, []);
  return list.sort((a, b) => b.updatedAt - a.updatedAt);
}

export function saveTournaments(tournaments: Tournament[]): void {
  safeWrite(KEYS.TOURNAMENTS, tournaments);
}

export function createQuickTeam(name: string, shortName: string, playerNames: string[]): Team {
  const now = Date.now();
  const players: Player[] = playerNames
    .map((n) => n.trim())
    .filter(Boolean)
    .map((n, idx) => ({
      id: createId(`p${idx}`),
      name: n,
      role: idx === 0 ? 'BAT' : 'AR',
    }));

  return {
    id: createId('team'),
    name: name.trim(),
    shortName: shortName.trim().toUpperCase().slice(0, 4) || 'TM',
    players,
    defaultCaptainId: players[0]?.id,
    defaultKeeperId: players[1]?.id || players[0]?.id,
    defaultPlayingXI: players.slice(0, 11).map((p) => p.id),
    createdAt: now,
    updatedAt: now,
  };
}

export interface CricXBackupPayload {
  app: 'CRIC X';
  version: 1;
  exportedAt: number;
  teams: Team[];
  matches: Match[];
  tournaments: Tournament[];
}

export function exportBackupData(): CricXBackupPayload {
  return {
    app: 'CRIC X',
    version: 1,
    exportedAt: Date.now(),
    teams: loadTeams(),
    matches: loadMatches(),
    tournaments: loadTournaments(),
  };
}

export function importBackupData(rawJson: string): CricXBackupPayload | null {
  try {
    const parsed = JSON.parse(rawJson) as Partial<CricXBackupPayload>;
    if (
      parsed.app !== 'CRIC X' ||
      !Array.isArray(parsed.teams) ||
      !Array.isArray(parsed.matches) ||
      !Array.isArray(parsed.tournaments)
    ) {
      return null;
    }
    saveTeams(parsed.teams);
    saveMatches(parsed.matches);
    saveTournaments(parsed.tournaments);
    localStorage.setItem(KEYS.SEEDED, '1');
    return {
      app: 'CRIC X',
      version: 1,
      exportedAt: parsed.exportedAt || Date.now(),
      teams: parsed.teams,
      matches: parsed.matches,
      tournaments: parsed.tournaments,
    };
  } catch {
    return null;
  }
}

