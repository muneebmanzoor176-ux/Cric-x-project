# CRIC X — Complete Offline Cricket Scorer

## Option 1: Instant Android Installation (No Android Studio Needed)
1. Open the CRIC X web app in Chrome on Android.
2. Tap **Install App** (or Chrome Menu -> **Add to Home screen**).
3. CRIC X installs with its black-and-white icon and runs 100% offline.

## Option 2: Build Native Debug / Release APK in Android Studio
1. Extract this ZIP file.
2. Open **Android Studio** -> **Open** -> select the `CRICX-Android/` folder.
3. Let Gradle sync (uses minimal `androidx.webkit` only, minSdk 26 / Android 8.0+).
4. Build APK:
   - Debug APK: **Build > Build Bundle(s) / APK(s) > Build APK(s)**
   - Signed Release APK: **Build > Generate Signed Bundle / APK...**
5. Because CRIC X uses pure monochrome vector/minimal assets and R8 shrinking (`minifyEnabled true`), the resulting offline APK is lightweight (< 4 MB typical).
